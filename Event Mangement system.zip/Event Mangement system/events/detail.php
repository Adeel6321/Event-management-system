<?php
/**
 * EMS — Event Detail View
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect(SITE_URL . '/events/index.php');

$stmt = $pdo->prepare("
    SELECT e.*, v.name AS venue_name, v.address, v.city, v.images AS venue_images,
           u.name AS organizer_name
    FROM events e
    LEFT JOIN venues v ON e.venue_id = v.id
    LEFT JOIN users u ON e.organizer_id = u.id
    WHERE e.id = ?
");
$stmt->execute([$id]);
$event = $stmt->fetch();

if (!$event || ($event['status'] !== 'published' && !isAdmin() && !isOrganizer())) {
    setFlash('danger', 'Event not found or unavailable.');
    redirect(SITE_URL . '/events/index.php');
}

$pageTitle  = $event['title'];
$activePage = 'events';
$seatsLeft  = $event['capacity'] - $event['registered'];
$isPast     = strtotime($event['date'] . ' ' . $event['time']) < time();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
  <div class="page-breadcrumb mb-3 scroll-animate">
    <a href="<?= SITE_URL ?>/index.php">Home</a> / 
    <a href="<?= SITE_URL ?>/events/index.php">Events</a> / 
    <span class="text-primary"><?= e($event['title']) ?></span>
  </div>

  <div class="row g-5">
    <div class="col-lg-8">
      
      <!-- Hero Banner -->
      <div class="event-detail-hero scroll-animate" style="background: linear-gradient(135deg, <?= categoryColor($event['category']) ?>33, var(--bg-card)); border: 1px solid <?= categoryColor($event['category']) ?>55">
        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:12rem;opacity:.05">
          <?= match($event['category']) { 'conference'=>'🎤', 'wedding'=>'💍', 'music'=>'🎵', 'sports'=>'🏆', 'cultural'=>'🎭', 'corporate'=>'💼', 'seminar'=>'🎓', default=>'📅' } ?>
        </div>
        <div class="event-detail-hero-content w-100">
          <div class="d-flex gap-2 mb-3">
            <span class="badge" style="background:<?= categoryColor($event['category']) ?>;color:#fff">
              <i class="bi <?= categoryIcon($event['category']) ?> me-1"></i><?= ucfirst($event['category']) ?>
            </span>
            <?= statusBadge($event['status']) ?>
          </div>
          <h1 class="page-title mb-2"><?= e($event['title']) ?></h1>
          <p class="text-secondary mb-0">Organized by <?= e($event['organizer_name']) ?></p>
        </div>
      </div>

      <div class="event-info-grid scroll-animate">
        <div class="event-info-item">
          <div class="event-info-icon"><i class="bi bi-calendar-event"></i></div>
          <div>
            <div class="event-info-label">Date & Time</div>
            <div class="event-info-value"><?= formatDate($event['date']) ?><br><?= formatTime($event['time']) ?></div>
          </div>
        </div>
        <div class="event-info-item">
          <div class="event-info-icon"><i class="bi bi-geo-alt"></i></div>
          <div>
            <div class="event-info-label">Location</div>
            <div class="event-info-value">
              <?php if($event['venue_name']): ?>
                <?= e($event['venue_name']) ?><br>
                <span class="text-muted fw-normal" style="font-size:.8rem"><?= e($event['city']) ?></span>
              <?php else: ?>
                TBA
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="event-info-item">
          <div class="event-info-icon"><i class="bi bi-people"></i></div>
          <div>
            <div class="event-info-label">Availability</div>
            <div class="event-info-value">
              <?php if($seatsLeft > 0): ?>
                <span class="text-success"><?= $seatsLeft ?> seats left</span>
              <?php else: ?>
                <span class="text-danger">Sold Out</span>
              <?php endif; ?>
              <br><span class="text-muted fw-normal" style="font-size:.8rem">Total: <?= $event['capacity'] ?></span>
            </div>
          </div>
        </div>
      </div>

      <div class="card-ems p-4 mb-4 scroll-animate">
        <h4 class="mb-3">About this Event</h4>
        <div style="line-height:1.8;color:var(--text-secondary)">
          <?= nl2br(e($event['description'])) ?>
        </div>
        <?php if($event['tags']): ?>
          <div class="mt-4 pt-3 border-top border-glass">
            <div class="event-info-label mb-2">Tags:</div>
            <div class="d-flex flex-wrap gap-2">
              <?php foreach(explode(',', $event['tags']) as $tag): ?>
                <span class="badge badge-secondary">#<?= e(trim($tag)) ?></span>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endif; ?>
      </div>

    </div>

    <!-- Sidebar / Booking Box -->
    <div class="col-lg-4 scroll-animate">
      <div class="booking-box">
        <div class="mb-4">
          <div class="event-info-label mb-1 text-uppercase tracking-wide">Ticket Price</div>
          <div class="booking-price text-gradient">
            <?= $event['type'] === 'free' ? 'Free' : 'PKR ' . number_format($event['ticket_price']) ?>
          </div>
        </div>

        <div class="mb-4">
          <?= capacityBar($event['registered'], $event['capacity']) ?>
        </div>

        <?php if ($isPast): ?>
          <div class="alert-custom alert-secondary text-center justify-content-center">
            This event has already ended.
          </div>
        <?php elseif ($event['status'] !== 'published'): ?>
          <div class="alert-custom alert-warning text-center justify-content-center">
            Booking is not open yet.
          </div>
        <?php elseif ($seatsLeft <= 0): ?>
          <div class="alert-custom alert-danger text-center justify-content-center">
            Tickets Sold Out
          </div>
        <?php else: ?>
          <a href="<?= SITE_URL ?>/bookings/book.php?event_id=<?= $event['id'] ?>" class="btn-ems btn-gold-ems w-100 justify-content-center btn-lg-ems mb-3">
            Book Your Seat <i class="bi bi-arrow-right"></i>
          </a>
          <p class="text-center text-muted" style="font-size:.8rem">Secure booking via EMS</p>
        <?php endif; ?>

        <hr class="border-glass my-4">
        
        <div class="text-center">
          <div class="event-info-label mb-2">Share this event</div>
          <div class="social-links justify-content-center">
            <a href="#" class="social-link"><i class="bi bi-facebook"></i></a>
            <a href="#" class="social-link"><i class="bi bi-twitter-x"></i></a>
            <a href="#" class="social-link"><i class="bi bi-whatsapp"></i></a>
            <a href="#" class="social-link" onclick="navigator.clipboard.writeText(window.location.href);alert('Link copied!')"><i class="bi bi-link-45deg"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
