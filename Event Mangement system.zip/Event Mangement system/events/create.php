<?php
/**
 * EMS — Create Event (Admin & Organizer)
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireOrganizer();

$pageTitle  = 'Create Event';
$activePage = 'create_event';
$errors     = [];

// Fetch venues for dropdown
$venues = $pdo->query("SELECT id, name FROM venues WHERE availability = 1 ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please try again.';
    } else {
        $title       = $_POST['title'] ?? '';
        $description = $_POST['description'] ?? '';
        $date        = $_POST['date'] ?? '';
        $time        = $_POST['time'] ?? '';
        $venue_id    = $_POST['venue_id'] ?? null;
        $category    = $_POST['category'] ?? 'other';
        $type        = $_POST['type'] ?? 'free';
        $price       = $_POST['ticket_price'] ?? 0;
        $capacity    = $_POST['capacity'] ?? 100;
        $tags        = $_POST['tags'] ?? '';
        $status      = $_POST['status'] ?? 'draft';

        if (empty($title) || empty($date) || empty($time) || empty($venue_id)) {
            $errors[] = 'Please fill in all required fields (Title, Date, Time, Venue).';
        }

        $imagePath = null;
        if (isset($_FILES['banner_image']) && $_FILES['banner_image']['error'] === UPLOAD_ERR_OK) {
            $upload = uploadImage($_FILES['banner_image'], 'events');
            if ($upload) {
                $imagePath = $upload;
            } else {
                $errors[] = 'Failed to upload event image. Ensure it is a valid image under 5MB.';
            }
        }

        if (empty($errors)) {
            $stmt = $pdo->prepare('
                INSERT INTO events (title, description, date, time, venue_id, category, type, 
                                    ticket_price, capacity, tags, status, organizer_id, banner_image)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ');
            $success = $stmt->execute([
                $title, $description, $date, $time, $venue_id, $category, $type,
                $price, $capacity, $tags, $status, $_SESSION['user_id'], $imagePath
            ]);

            if ($success) {
                $eventId = $pdo->lastInsertId();
                setFlash('success', 'Event created successfully!');
                redirect(SITE_URL . '/events/detail.php?id=' . $eventId);
            } else {
                $errors[] = 'Failed to create event. Please try again.';
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      
      <div class="d-flex align-items-center justify-content-between mb-4 scroll-animate">
        <h1 class="page-title mb-0">Create New Event</h1>
        <a href="<?= SITE_URL ?>/events/index.php" class="btn-ems btn-ghost-ems btn-sm-ems">Cancel</a>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert-custom alert-danger mb-4 scroll-animate">
          <ul class="mb-0 ps-3">
            <?php foreach ($errors as $e) echo "<li>" . e($e) . "</li>"; ?>
          </ul>
        </div>
      <?php endif; ?>

      <div class="card-ems p-4 p-md-5 scroll-animate">
        <form method="POST" action="" class="needs-validation" enctype="multipart/form-data" novalidate>
          <?= csrfField() ?>

          <h5 class="mb-4 pb-2 border-bottom border-glass text-purple">Basic Information</h5>
          
          <div class="form-group-ems">
            <label class="form-label-ems">Event Title *</label>
            <input type="text" name="title" class="form-control-ems" required placeholder="E.g., Annual Tech Summit 2026">
          </div>

          <div class="form-group-ems">
            <label class="form-label-ems">Description</label>
            <textarea name="description" class="form-control-ems" rows="4" placeholder="Detail what the event is about..."></textarea>
          </div>

          <div class="form-group-ems">
            <label class="form-label-ems">Banner Image</label>
            <input type="file" name="banner_image" class="form-control-ems" accept="image/jpeg,image/png,image/webp,image/gif" id="imgUpload">
            <div class="text-muted mt-1" style="font-size:.75rem">Recommended size: 1200x600px. Max: 5MB.</div>
            <img id="imgPreview" src="" alt="Preview" class="mt-3 rounded" style="display:none; max-width: 100%; height: 200px; object-fit: cover;">
          </div>

          <div class="row g-3 mb-4">
            <div class="col-md-6 form-group-ems mb-0">
              <label class="form-label-ems">Category *</label>
              <select name="category" class="form-control-ems form-select-ems">
                <option value="conference">Conference</option>
                <option value="seminar">Seminar</option>
                <option value="workshop">Workshop</option>
                <option value="sports">Sports</option>
                <option value="cultural">Cultural</option>
                <option value="music">Music</option>
                <option value="other" selected>Other</option>
              </select>
            </div>
            <div class="col-md-6 form-group-ems mb-0">
              <label class="form-label-ems">Tags</label>
              <input type="text" name="tags" class="form-control-ems" placeholder="Comma separated (e.g., tech, AI, networking)">
            </div>
          </div>

          <h5 class="mb-4 pb-2 border-bottom border-glass text-purple mt-5">Schedule & Location</h5>

          <div class="row g-3 mb-3">
            <div class="col-md-6 form-group-ems mb-0">
              <label class="form-label-ems">Date *</label>
              <input type="date" name="date" class="form-control-ems" required min="<?= date('Y-m-d') ?>">
            </div>
            <div class="col-md-6 form-group-ems mb-0">
              <label class="form-label-ems">Time *</label>
              <input type="time" name="time" class="form-control-ems" required>
            </div>
          </div>

          <div class="form-group-ems mb-4">
            <label class="form-label-ems">Venue *</label>
            <select name="venue_id" class="form-control-ems form-select-ems" required>
              <option value="">-- Select Venue --</option>
              <?php foreach ($venues as $v): ?>
                <option value="<?= $v['id'] ?>"><?= e($v['name']) ?></option>
              <?php endforeach; ?>
            </select>
            <div class="form-text mt-1 text-muted" style="font-size:.8rem">Can't find it? <a href="<?= SITE_URL ?>/venues/add.php">Add a new venue</a></div>
          </div>

          <h5 class="mb-4 pb-2 border-bottom border-glass text-purple mt-5">Ticketing & Status</h5>

          <div class="row g-3 mb-3">
            <div class="col-md-4 form-group-ems mb-0">
              <label class="form-label-ems">Event Type</label>
              <select name="type" class="form-control-ems form-select-ems" id="eventTypeSelect" onchange="document.getElementById('priceInput').style.display = this.value === 'paid' ? 'block' : 'none'">
                <option value="free">Free</option>
                <option value="paid">Paid</option>
              </select>
            </div>
            <div class="col-md-4 form-group-ems mb-0" id="priceInput" style="display:none">
              <label class="form-label-ems">Ticket Price (PKR)</label>
              <input type="number" name="ticket_price" class="form-control-ems" min="0" step="100" value="0">
            </div>
            <div class="col-md-4 form-group-ems mb-0">
              <label class="form-label-ems">Total Capacity</label>
              <input type="number" name="capacity" class="form-control-ems" min="1" value="100" required>
            </div>
          </div>

          <div class="form-group-ems mb-5">
            <label class="form-label-ems">Initial Status</label>
            <select name="status" class="form-control-ems form-select-ems">
              <option value="draft">Draft (Private, save for later)</option>
              <option value="published">Published (Public, open for booking)</option>
            </select>
          </div>

          <button type="submit" class="btn-ems btn-primary-ems w-100 justify-content-center btn-lg-ems">
            <i class="bi bi-save"></i> Save Event
          </button>
        </form>
      </div>

    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
