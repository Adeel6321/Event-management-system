<?php
/**
 * EMS — Events Listing & Search
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$pageTitle  = 'Explore Events';
$activePage = 'events';

// Search and filters
$search   = $_GET['q'] ?? '';
$category = $_GET['category'] ?? '';
$type     = $_GET['type'] ?? '';
$date     = $_GET['date'] ?? '';

$where = ["e.status = 'published'"];
$params = [];

if ($search) {
    $where[]  = "(e.title LIKE ? OR e.description LIKE ? OR e.tags LIKE ?)";
    $term     = "%$search%";
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}
if ($category) {
    $where[]  = "e.category = ?";
    $params[] = $category;
}
if ($type) {
    $where[]  = "e.type = ?";
    $params[] = $type;
}
if ($date) {
    if ($date === 'today') {
        $where[] = "e.date = CURDATE()";
    } elseif ($date === 'upcoming') {
        $where[] = "e.date >= CURDATE()";
    } elseif ($date === 'past') {
        $where[] = "e.date < CURDATE()";
    }
} else {
    // Default: show upcoming + today
    $where[] = "e.date >= CURDATE()";
}

$whereClause = implode(' AND ', $where);

// Pagination
$perPage = 9;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$totalCount = $pdo->prepare("SELECT COUNT(*) FROM events e WHERE $whereClause");
$totalCount->execute($params);
$totalEvents = $totalCount->fetchColumn();

// Fetch events
$sql = "SELECT e.*, v.name AS venue_name, v.city 
        FROM events e 
        LEFT JOIN venues v ON e.venue_id = v.id 
        WHERE $whereClause 
        ORDER BY e.date ASC 
        LIMIT $perPage OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$events = $stmt->fetchAll();

// Build URL pattern for pagination
$qs = $_GET;
$qs['page'] = '{page}';
$urlPattern = '?' . http_build_query($qs);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
  <div class="row g-4 align-items-center mb-5">
    <div class="col-lg-6 scroll-animate">
      <h1 class="page-title mb-2">Explore Events</h1>
      <p class="text-secondary">Discover conferences, seminars, and cultural events happening at IUB.</p>
    </div>
    <div class="col-lg-6 scroll-animate">
      <form action="" method="GET" class="search-bar ms-lg-auto" id="searchForm">
        <i class="bi bi-search text-muted px-2"></i>
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search by name, tags..." id="liveSearch">
        <button type="submit" class="btn-ems btn-primary-ems" style="padding:.4rem 1rem;border-radius:var(--r-md)">
          Search
        </button>
      </form>
    </div>
  </div>

  <div class="row g-4">
    <!-- Sidebar Filters -->
    <div class="col-lg-3 scroll-animate">
      <div class="glass p-4 sticky-top" style="top:90px;z-index:10">
        <h5 class="mb-4 d-flex align-items-center gap-2">
          <i class="bi bi-funnel text-purple"></i> Filters
        </h5>
        
        <form action="" method="GET">
          <?php if($search): ?><input type="hidden" name="q" value="<?= e($search) ?>"><?php endif; ?>
          
          <div class="mb-4">
            <label class="form-label-ems">Category</label>
            <select name="category" class="form-control-ems form-select-ems" onchange="this.form.submit()">
              <option value="">All Categories</option>
              <?php foreach(['conference','seminar','sports','cultural','music','corporate','wedding','other'] as $c): ?>
                <option value="<?= $c ?>" <?= $category === $c ? 'selected' : '' ?>><?= ucfirst($c) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-4">
            <label class="form-label-ems">Type</label>
            <div class="d-flex flex-column gap-2">
              <label class="d-flex align-items-center gap-2" style="cursor:pointer">
                <input type="radio" name="type" value="" <?= $type==='' ? 'checked' : '' ?> onchange="this.form.submit()"> Any
              </label>
              <label class="d-flex align-items-center gap-2" style="cursor:pointer">
                <input type="radio" name="type" value="free" <?= $type==='free' ? 'checked' : '' ?> onchange="this.form.submit()"> Free
              </label>
              <label class="d-flex align-items-center gap-2" style="cursor:pointer">
                <input type="radio" name="type" value="paid" <?= $type==='paid' ? 'checked' : '' ?> onchange="this.form.submit()"> Paid
              </label>
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label-ems">Date</label>
            <select name="date" class="form-control-ems form-select-ems" onchange="this.form.submit()">
              <option value="upcoming" <?= $date==='upcoming' ? 'selected' : '' ?>>Upcoming (Default)</option>
              <option value="today" <?= $date==='today' ? 'selected' : '' ?>>Today</option>
              <option value="past" <?= $date==='past' ? 'selected' : '' ?>>Past Events</option>
              <option value="" <?= $date==='' ? 'selected' : '' ?>>Any Date</option>
            </select>
          </div>

          <?php if($search || $category || $type || $date): ?>
            <a href="index.php" class="btn-ems btn-outline-ems w-100 justify-content-center btn-sm-ems">
              Clear Filters
            </a>
          <?php endif; ?>
        </form>
      </div>
    </div>

    <!-- Events Grid -->
    <div class="col-lg-9">
      <?php if (empty($events)): ?>
        <div class="empty-state scroll-animate">
          <i class="bi bi-search"></i>
          <h4>No events found</h4>
          <p>Try adjusting your search or filters to find what you're looking for.</p>
          <a href="index.php" class="btn-ems btn-primary-ems mt-3">Reset Search</a>
        </div>
      <?php else: ?>
        <div class="mb-3 text-secondary scroll-animate">
          Showing <?= count($events) ?> of <?= $totalEvents ?> events
        </div>
        
        <div class="row g-4 mb-5">
          <?php foreach ($events as $ev): ?>
          <div class="col-md-6 col-xl-4 scroll-animate">
            <div class="card-ems h-100">
              <div class="card-event-banner" style="background:linear-gradient(135deg,<?= categoryColor($ev['category']) ?>22,<?= categoryColor($ev['category']) ?>08)">
                <div style="font-size:3.5rem; opacity:.8">
                  <?= match($ev['category']) {
                    'conference' => '🎤', 'wedding' => '💍', 'music' => '🎵',
                    'sports'     => '🏆', 'cultural' => '🎭', 'corporate' => '💼',
                    'seminar'    => '🎓', default    => '📅',
                  } ?>
                </div>
                <div style="position:absolute;top:12px;right:12px">
                  <?= $ev['type'] === 'paid'
                    ? "<span class='badge badge-warning'>PKR " . number_format($ev['ticket_price']) . "</span>"
                    : "<span class='badge badge-success'>Free</span>" ?>
                </div>
              </div>

              <div class="card-body-ems d-flex flex-column">
                <div class="event-category-badge" style="background:<?= categoryColor($ev['category']) ?>20;color:<?= categoryColor($ev['category']) ?>">
                  <i class="bi <?= categoryIcon($ev['category']) ?>"></i>
                  <?= ucfirst($ev['category']) ?>
                </div>

                <h3 class="card-title-ems"><?= e($ev['title']) ?></h3>

                <div class="card-meta">
                  <span><i class="bi bi-calendar3 text-purple"></i> <?= formatDate($ev['date']) ?></span>
                  <?php if ($ev['venue_name']): ?>
                  <span><i class="bi bi-geo-alt text-purple"></i> <?= e($ev['venue_name']) ?></span>
                  <?php endif; ?>
                </div>

                <?= capacityBar($ev['registered'], $ev['capacity']) ?>

                <div class="mt-auto pt-3">
                  <a href="detail.php?id=<?= $ev['id'] ?>" class="btn-ems btn-primary-ems w-100 justify-content-center btn-sm-ems">
                    View Event
                  </a>
                </div>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <?= paginate($totalEvents, $perPage, $page, $urlPattern) ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
