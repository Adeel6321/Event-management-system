<?php
/**
 * EMS — Edit Event
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireOrganizer();

$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect(SITE_URL . '/events/index.php');

$stmt = $pdo->prepare("SELECT * FROM events WHERE id = ?");
$stmt->execute([$id]);
$event = $stmt->fetch();

if (!$event) {
    setFlash('danger', 'Event not found.');
    redirect(SITE_URL . '/events/index.php');
}

// Only admin or the specific organizer can edit
if (!isAdmin() && $event['organizer_id'] !== $_SESSION['user_id']) {
    setFlash('danger', 'You do not have permission to edit this event.');
    redirect(SITE_URL . '/events/index.php');
}

$pageTitle  = 'Edit Event';
$activePage = 'events';
$errors     = [];

// Fetch venues for dropdown
$venues = $pdo->query("SELECT id, name FROM venues WHERE availability = 1 ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please try again.';
    } else {
        $title       = $_POST['title'] ?? '';
        $description = $_POST['description'] ?? '';
        $date        = $_POST['date'] ?? '';
        $time        = $_POST['time'] ?? '';
        $venue_id    = $_POST['venue_id'] ?? null;
        $category    = $_POST['category'] ?? 'other';
        $type        = $_POST['type'] ?? 'free';
        $price       = $_POST['ticket_price'] ?? 0;
        $capacity    = $_POST['capacity'] ?? 100;
        $tags        = $_POST['tags'] ?? '';
        $status      = $_POST['status'] ?? 'draft';

        if (empty($title) || empty($date) || empty($time) || empty($venue_id)) {
            $errors[] = 'Please fill in all required fields.';
        }

        $imagePath = $event['banner_image'];
        if (isset($_FILES['banner_image']) && $_FILES['banner_image']['error'] === UPLOAD_ERR_OK) {
            $upload = uploadImage($_FILES['banner_image'], 'events');
            if ($upload) {
                $imagePath = $upload;
            } else {
                $errors[] = 'Failed to upload event image. Ensure it is a valid image under 5MB.';
            }
        }

        if (empty($errors)) {
            $stmt = $pdo->prepare('
                UPDATE events SET 
                title=?, description=?, date=?, time=?, venue_id=?, category=?, type=?, 
                ticket_price=?, capacity=?, tags=?, status=?, banner_image=?
                WHERE id=?
            ');
            $success = $stmt->execute([
                $title, $description, $date, $time, $venue_id, $category, $type,
                $price, $capacity, $tags, $status, $imagePath, $id
            ]);

            if ($success) {
                setFlash('success', 'Event updated successfully!');
                redirect(SITE_URL . '/events/detail.php?id=' . $id);
            } else {
                $errors[] = 'Failed to update event.';
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      
      <div class="d-flex align-items-center justify-content-between mb-4 scroll-animate">
        <h1 class="page-title mb-0">Edit Event</h1>
        <a href="<?= SITE_URL ?>/events/detail.php?id=<?= $id ?>" class="btn-ems btn-ghost-ems btn-sm-ems">Cancel</a>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert-custom alert-danger mb-4 scroll-animate">
          <ul class="mb-0 ps-3">
            <?php foreach ($errors as $e) echo "<li>" . e($e) . "</li>"; ?>
          </ul>
        </div>
      <?php endif; ?>

      <div class="card-ems p-4 p-md-5 scroll-animate">
        <form method="POST" action="" class="needs-validation" enctype="multipart/form-data" novalidate>
          <?= csrfField() ?>

          <h5 class="mb-4 pb-2 border-bottom border-glass text-purple">Basic Information</h5>
          
          <div class="form-group-ems">
            <label class="form-label-ems">Event Title *</label>
            <input type="text" name="title" class="form-control-ems" required value="<?= e($event['title']) ?>">
          </div>

          <div class="form-group-ems">
            <label class="form-label-ems">Description</label>
            <textarea name="description" class="form-control-ems" rows="4"><?= e($event['description']) ?></textarea>
          </div>

          <div class="form-group-ems">
            <label class="form-label-ems">Banner Image</label>
            <?php if($event['banner_image']): ?>
              <div class="mb-2">
                <img src="<?= SITE_URL ?>/assets/uploads/<?= e($event['banner_image']) ?>" alt="Current Banner" style="max-width:100%; height:150px; object-fit:cover; border-radius:8px">
              </div>
            <?php endif; ?>
            <input type="file" name="banner_image" class="form-control-ems" accept="image/jpeg,image/png,image/webp,image/gif" id="imgUpload">
            <div class="text-muted mt-1" style="font-size:.75rem">Upload new image to replace current. Recommended: 1200x600px. Max: 5MB.</div>
            <img id="imgPreview" src="" alt="Preview" class="mt-3 rounded" style="display:none; max-width: 100%; height: 200px; object-fit: cover;">
          </div>

          <div class="row g-3 mb-4">
            <div class="col-md-6 form-group-ems mb-0">
              <label class="form-label-ems">Category *</label>
              <select name="category" class="form-control-ems form-select-ems">
                <?php foreach(['conference','seminar','workshop','sports','cultural','music','other'] as $cat): ?>
                <option value="<?= $cat ?>" <?= $event['category']===$cat ? 'selected' : '' ?>><?= ucfirst($cat) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6 form-group-ems mb-0">
              <label class="form-label-ems">Tags</label>
              <input type="text" name="tags" class="form-control-ems" value="<?= e($event['tags']) ?>">
            </div>
          </div>

          <h5 class="mb-4 pb-2 border-bottom border-glass text-purple mt-5">Schedule & Location</h5>

          <div class="row g-3 mb-3">
            <div class="col-md-6 form-group-ems mb-0">
              <label class="form-label-ems">Date *</label>
              <input type="date" name="date" class="form-control-ems" required value="<?= e($event['date']) ?>">
            </div>
            <div class="col-md-6 form-group-ems mb-0">
              <label class="form-label-ems">Time *</label>
              <input type="time" name="time" class="form-control-ems" required value="<?= e($event['time']) ?>">
            </div>
          </div>

          <div class="form-group-ems mb-4">
            <label class="form-label-ems">Venue *</label>
            <select name="venue_id" class="form-control-ems form-select-ems" required>
              <?php foreach ($venues as $v): ?>
                <option value="<?= $v['id'] ?>" <?= $event['venue_id']==$v['id'] ? 'selected' : '' ?>><?= e($v['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <h5 class="mb-4 pb-2 border-bottom border-glass text-purple mt-5">Ticketing & Status</h5>

          <div class="row g-3 mb-3">
            <div class="col-md-4 form-group-ems mb-0">
              <label class="form-label-ems">Event Type</label>
              <select name="type" class="form-control-ems form-select-ems" id="eventTypeSelect" onchange="document.getElementById('priceInput').style.display = this.value === 'paid' ? 'block' : 'none'">
                <option value="free" <?= $event['type']==='free' ? 'selected' : '' ?>>Free</option>
                <option value="paid" <?= $event['type']==='paid' ? 'selected' : '' ?>>Paid</option>
              </select>
            </div>
            <div class="col-md-4 form-group-ems mb-0" id="priceInput" style="display:<?= $event['type']==='paid' ? 'block' : 'none' ?>">
              <label class="form-label-ems">Ticket Price (PKR)</label>
              <input type="number" name="ticket_price" class="form-control-ems" min="0" step="100" value="<?= e($event['ticket_price']) ?>">
            </div>
            <div class="col-md-4 form-group-ems mb-0">
              <label class="form-label-ems">Total Capacity</label>
              <input type="number" name="capacity" class="form-control-ems" min="1" value="<?= e($event['capacity']) ?>" required>
            </div>
          </div>

          <div class="form-group-ems mb-5">
            <label class="form-label-ems">Status</label>
            <select name="status" class="form-control-ems form-select-ems">
              <option value="draft" <?= $event['status']==='draft' ? 'selected' : '' ?>>Draft</option>
              <option value="published" <?= $event['status']==='published' ? 'selected' : '' ?>>Published</option>
              <option value="cancelled" <?= $event['status']==='cancelled' ? 'selected' : '' ?>>Cancelled</option>
              <option value="completed" <?= $event['status']==='completed' ? 'selected' : '' ?>>Completed</option>
            </select>
          </div>

          <button type="submit" class="btn-ems btn-primary-ems w-100 justify-content-center btn-lg-ems">
            <i class="bi bi-check2-circle"></i> Update Event
          </button>
        </form>
      </div>

    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
