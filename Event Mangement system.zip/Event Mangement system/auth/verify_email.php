<?php
/**
 * EMS — Verify Email
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$token = $_GET['token'] ?? '';

if (empty($token)) {
    setFlash('danger', 'Invalid verification link.');
    redirect(SITE_URL . '/index.php');
}

$stmt = $pdo->prepare('SELECT id, email_verified FROM users WHERE verification_token = ?');
$stmt->execute([$token]);
$user = $stmt->fetch();

if (!$user) {
    setFlash('danger', 'Invalid or expired verification link.');
    redirect(SITE_URL . '/index.php');
}

if ($user['email_verified']) {
    setFlash('info', 'Your email is already verified. You can log in.');
    redirect(SITE_URL . '/auth/login.php');
}

// Mark as verified
$stmt = $pdo->prepare('UPDATE users SET email_verified = 1, verification_token = NULL WHERE id = ?');
$stmt->execute([$user['id']]);

setFlash('success', 'Your email has been verified successfully! You can now log in.');
redirect(SITE_URL . '/auth/login.php');
