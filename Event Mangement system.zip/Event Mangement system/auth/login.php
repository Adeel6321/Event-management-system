<?php
/**
 * EMS — Login Page
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

redirectIfLoggedIn();

$pageTitle = 'Login';
$errors    = [];
$email     = $_POST['email'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please try again.';
    } else {
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $errors[] = 'Please fill in all fields.';
        } elseif (checkLoginLockout($pdo, $email)) {
            $mins = getRemainingLockout($pdo, $email);
            $errors[] = "Account temporarily locked. Try again in {$mins} minutes.";
        } else {
            $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                if (!$user['is_active']) {
                    $errors[] = 'Your account has been deactivated. Please contact support.';
                } else {
                    // Login success
                    clearLoginAttempts($pdo, $email);
                    $_SESSION['user_id']    = $user['id'];
                    $_SESSION['user_name']  = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_role']  = $user['role'];

                    setFlash('success', 'Welcome back, ' . e($user['name']) . '!');
                    $redirect = $_SESSION['intended'] ?? SITE_URL . '/index.php';
                    unset($_SESSION['intended']);
                    redirect($redirect);
                }
            } else {
                // Login failed
                recordFailedLogin($pdo, $email, $_SERVER['REMOTE_ADDR']);
                $errors[] = 'Invalid email or password.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | EMS</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body class="auth-page">
  <div class="bg-mesh"></div>
  <div class="auth-card">
    <div class="auth-logo">
      <div class="brand-icon mx-auto mb-3" style="width:56px;height:56px;font-size:1.6rem">🎫</div>
      <h2>Welcome Back</h2>
      <p>Log in to manage your events and bookings</p>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="alert-custom alert-danger mb-4">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>
        <ul class="mb-0 ps-3">
          <?php foreach ($errors as $e) echo "<li>" . e($e) . "</li>"; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?= renderFlash() ?>

    <form method="POST" action="" class="needs-validation" novalidate>
      <?= csrfField() ?>
      
      <div class="form-group-ems">
        <label class="form-label-ems">Email Address</label>
        <div class="input-icon-wrap">
          <i class="bi bi-envelope icon"></i>
          <input type="email" name="email" class="form-control-ems" value="<?= e($email) ?>" required autofocus placeholder="name@example.com">
        </div>
      </div>

      <div class="form-group-ems mb-4">
        <div class="d-flex justify-content-between align-items-center">
          <label class="form-label-ems mb-0">Password</label>
          <a href="#" style="font-size:.8rem">Forgot password?</a>
        </div>
        <div class="input-icon-wrap mt-2">
          <i class="bi bi-lock icon"></i>
          <input type="password" name="password" class="form-control-ems" required placeholder="Enter your password">
        </div>
      </div>

      <button type="submit" class="btn-ems btn-primary-ems w-100 justify-content-center btn-lg-ems">
        Log In <i class="bi bi-arrow-right"></i>
      </button>

      <div class="text-center mt-4" style="font-size:.88rem;color:var(--text-secondary)">
        Don't have an account? <a href="register.php" style="font-weight:600">Register now</a>
      </div>
    </form>
  </div>
</body>
</html>
