<?php
/**
 * EMS — Registration Page
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/mailer.php';
require_once __DIR__ . '/../includes/auth_check.php';

redirectIfLoggedIn();

$pageTitle = 'Register';
$errors    = [];
$name      = $_POST['name'] ?? '';
$email     = $_POST['email'] ?? '';
$phone     = $_POST['phone'] ?? '';
$role      = $_POST['role'] ?? 'attendee';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please try again.';
    } else {
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        if (empty($name) || empty($email) || empty($password)) {
            $errors[] = 'Please fill in all required fields.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Invalid email address format.';
        } elseif (strlen($password) < 8) {
            $errors[] = 'Password must be at least 8 characters long.';
        } elseif ($password !== $confirm) {
            $errors[] = 'Passwords do not match.';
        } elseif (!in_array($role, ['attendee', 'organizer'])) {
            $errors[] = 'Invalid role selected.';
        } else {
            // Check if email exists
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $errors[] = 'Email is already registered.';
            } else {
                $hash  = password_hash($password, PASSWORD_DEFAULT);
                $token = bin2hex(random_bytes(32));

                $stmt = $pdo->prepare('INSERT INTO users (name, email, password, phone, role, verification_token) VALUES (?,?,?,?,?,?)');
                if ($stmt->execute([$name, $email, $hash, $phone, $role, $token])) {
                    $userId = $pdo->lastInsertId();
                    
                    // Create welcome notification
                    createNotification($pdo, $userId, 'Welcome to EMS!', 'Your account has been created successfully. Enjoy exploring events!');
                    
                    // Send verification email
                    sendVerificationEmail($email, $name, $token);

                    setFlash('success', 'Registration successful! Please log in. A verification email has been sent.');
                    redirect('login.php');
                } else {
                    $errors[] = 'Registration failed due to a database error.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register | EMS</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body class="auth-page py-5">
  <div class="bg-mesh"></div>
  <div class="auth-card" style="max-width:550px">
    <div class="auth-logo">
      <div class="brand-icon mx-auto mb-3" style="width:56px;height:56px;font-size:1.6rem">🎫</div>
      <h2>Create an Account</h2>
      <p>Join EMS to book and manage events</p>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="alert-custom alert-danger mb-4">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>
        <ul class="mb-0 ps-3">
          <?php foreach ($errors as $e) echo "<li>" . e($e) . "</li>"; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="POST" action="" class="needs-validation" novalidate>
      <?= csrfField() ?>
      
      <div class="row g-3 mb-3">
        <div class="col-md-6 form-group-ems mb-0">
          <label class="form-label-ems">Full Name *</label>
          <div class="input-icon-wrap">
            <i class="bi bi-person icon"></i>
            <input type="text" name="name" class="form-control-ems" value="<?= e($name) ?>" required>
          </div>
        </div>
        <div class="col-md-6 form-group-ems mb-0">
          <label class="form-label-ems">Phone Number</label>
          <div class="input-icon-wrap">
            <i class="bi bi-telephone icon"></i>
            <input type="text" name="phone" class="form-control-ems" value="<?= e($phone) ?>" placeholder="03xx-xxxxxxx">
          </div>
        </div>
      </div>

      <div class="form-group-ems">
        <label class="form-label-ems">Email Address *</label>
        <div class="input-icon-wrap">
          <i class="bi bi-envelope icon"></i>
          <input type="email" name="email" class="form-control-ems" value="<?= e($email) ?>" required>
        </div>
      </div>

      <div class="row g-3 mb-3">
        <div class="col-md-6 form-group-ems mb-0">
          <label class="form-label-ems">Password *</label>
          <div class="input-icon-wrap">
            <i class="bi bi-lock icon"></i>
            <input type="password" name="password" class="form-control-ems" required minlength="8">
          </div>
        </div>
        <div class="col-md-6 form-group-ems mb-0">
          <label class="form-label-ems">Confirm Password *</label>
          <div class="input-icon-wrap">
            <i class="bi bi-lock-fill icon"></i>
            <input type="password" name="confirm_password" class="form-control-ems" required minlength="8">
          </div>
        </div>
      </div>

      <div class="form-group-ems mb-4">
        <label class="form-label-ems">Account Type *</label>
        <select name="role" class="form-control-ems form-select-ems">
          <option value="attendee" <?= $role === 'attendee' ? 'selected' : '' ?>>Attendee (Book events)</option>
          <option value="organizer" <?= $role === 'organizer' ? 'selected' : '' ?>>Event Organizer (Host events)</option>
        </select>
      </div>

      <button type="submit" class="btn-ems btn-primary-ems w-100 justify-content-center btn-lg-ems">
        Create Account <i class="bi bi-person-plus-fill"></i>
      </button>

      <div class="text-center mt-4" style="font-size:.88rem;color:var(--text-secondary)">
        Already have an account? <a href="login.php" style="font-weight:600">Log in</a>
      </div>
    </form>
  </div>
</body>
</html>
