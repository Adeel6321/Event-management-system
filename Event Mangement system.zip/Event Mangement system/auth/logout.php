<?php
/**
 * EMS — Logout
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

session_unset();
session_destroy();
session_start(); // Start a new session for flash messages
setFlash('success', 'You have been successfully logged out.');
redirect(SITE_URL . '/auth/login.php');
