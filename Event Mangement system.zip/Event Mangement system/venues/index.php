<?php
/**
 * EMS — Venues Listing
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$pageTitle  = 'Venues';
$activePage = 'venues';

// Fetch venues
$search = $_GET['q'] ?? '';
$where = "availability = 1";
$params = [];

if ($search) {
    $where .= " AND (name LIKE ? OR location LIKE ? OR city LIKE ?)";
    $term = "%$search%";
    $params = [$term, $term, $term];
}

$stmt = $pdo->prepare("SELECT * FROM venues WHERE $where ORDER BY name ASC");
$stmt->execute($params);
$venues = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
  <div class="row g-4 align-items-center mb-5 scroll-animate">
    <div class="col-lg-6">
      <h1 class="page-title mb-2">Partner Venues</h1>
      <p class="text-secondary">Discover our partnered venues for hosting amazing events across the city.</p>
    </div>
    <div class="col-lg-6">
      <form action="" method="GET" class="search-bar ms-lg-auto">
        <i class="bi bi-search text-muted px-2"></i>
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search by venue name or location...">
        <button type="submit" class="btn-ems btn-primary-ems btn-sm-ems">Search</button>
      </form>
    </div>
  </div>

  <?php if (empty($venues)): ?>
    <div class="empty-state scroll-animate">
      <i class="bi bi-building-x"></i>
      <h4>No venues found</h4>
      <p>Try adjusting your search criteria.</p>
    </div>
  <?php else: ?>
    <div class="row g-4">
      <?php foreach ($venues as $v): ?>
      <div class="col-lg-4 col-md-6 scroll-animate">
        <div class="card-ems h-100 p-4 d-flex flex-column" style="background:var(--bg-card);border:1px solid var(--border-glass)">
          
          <div class="d-flex align-items-center gap-3 mb-4 border-bottom border-glass pb-3">
            <div class="stat-icon" style="background:rgba(245,158,11,.1);color:var(--gold)">
              <i class="bi bi-building"></i>
            </div>
            <div>
              <h4 class="mb-0 text-primary" style="font-size:1.1rem"><?= e($v['name']) ?></h4>
              <div class="text-secondary" style="font-size:.8rem"><i class="bi bi-geo-alt me-1"></i><?= e($v['city']) ?></div>
            </div>
          </div>

          <div class="mb-4 flex-grow-1">
            <div class="text-secondary mb-3" style="font-size:.85rem;line-height:1.6">
              <?= e(mb_strimwidth($v['description'], 0, 100, '...')) ?>
            </div>
            
            <div class="row g-2 mb-3">
              <div class="col-6">
                <div class="bg-input p-2 rounded-ems" style="background:rgba(255,255,255,.02);border:1px solid var(--border-glass)">
                  <div class="text-muted" style="font-size:.7rem">Capacity</div>
                  <div class="fw-bold text-primary" style="font-size:.9rem"><i class="bi bi-people-fill text-purple me-1"></i> <?= number_format($v['capacity']) ?></div>
                </div>
              </div>
              <div class="col-6">
                <div class="bg-input p-2 rounded-ems" style="background:rgba(255,255,255,.02);border:1px solid var(--border-glass)">
                  <div class="text-muted" style="font-size:.7rem">Status</div>
                  <div class="fw-bold text-success" style="font-size:.9rem"><i class="bi bi-check-circle-fill me-1"></i> Available</div>
                </div>
              </div>
            </div>
            
            <?php if($v['amenities']): ?>
            <div class="d-flex flex-wrap gap-1">
              <?php foreach(array_slice(explode(',', $v['amenities']), 0, 3) as $am): ?>
                <span class="badge badge-secondary" style="font-size:.7rem;font-weight:500"><?= e(trim($am)) ?></span>
              <?php endforeach; ?>
              <?php if(count(explode(',', $v['amenities'])) > 3): ?>
                <span class="badge badge-secondary" style="font-size:.7rem;font-weight:500">...</span>
              <?php endif; ?>
            </div>
            <?php endif; ?>
          </div>

          <a href="<?= SITE_URL ?>/venues/detail.php?id=<?= $v['id'] ?>" class="btn-ems btn-outline-ems w-100 justify-content-center btn-sm-ems mt-auto">
            View Details
          </a>

        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
