<?php
/**
 * EMS — Add Venue (Admin Only)
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();

$pageTitle  = 'Add Venue';
$activePage = 'venues';
$errors     = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request.';
    } else {
        $name      = $_POST['name'] ?? '';
        $location  = $_POST['location'] ?? '';
        $address   = $_POST['address'] ?? '';
        $city      = $_POST['city'] ?? '';
        $capacity  = (int)($_POST['capacity'] ?? 100);
        $desc      = $_POST['description'] ?? '';
        $amenities = $_POST['amenities'] ?? '';
        $contact   = $_POST['contact_person'] ?? '';
        $phone     = $_POST['contact_phone'] ?? '';
        $avail     = isset($_POST['availability']) ? 1 : 0;

        if (empty($name) || empty($location) || empty($capacity)) {
            $errors[] = 'Name, location, and capacity are required.';
        }

        if (empty($errors)) {
            $stmt = $pdo->prepare("
                INSERT INTO venues (name, location, address, city, capacity, description, amenities, contact_person, contact_phone, availability, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            if ($stmt->execute([$name, $location, $address, $city, $capacity, $desc, $amenities, $contact, $phone, $avail, $_SESSION['user_id']])) {
                setFlash('success', 'Venue added successfully.');
                redirect(SITE_URL . '/admin/venues.php');
            } else {
                $errors[] = 'Failed to add venue.';
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      
      <div class="d-flex align-items-center justify-content-between mb-4 scroll-animate">
        <h1 class="page-title mb-0">Add New Venue</h1>
        <a href="<?= SITE_URL ?>/admin/venues.php" class="btn-ems btn-ghost-ems btn-sm-ems">Back</a>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert-custom alert-danger mb-4 scroll-animate">
          <ul class="mb-0 ps-3">
            <?php foreach ($errors as $e) echo "<li>" . e($e) . "</li>"; ?>
          </ul>
        </div>
      <?php endif; ?>

      <div class="card-ems p-4 p-md-5 scroll-animate">
        <form method="POST" action="" class="needs-validation" novalidate>
          <?= csrfField() ?>

          <div class="row g-3 mb-4">
            <div class="col-md-8 form-group-ems mb-0">
              <label class="form-label-ems">Venue Name *</label>
              <input type="text" name="name" class="form-control-ems" required>
            </div>
            <div class="col-md-4 form-group-ems mb-0">
              <label class="form-label-ems">Capacity *</label>
              <input type="number" name="capacity" class="form-control-ems" min="1" required>
            </div>
          </div>

          <div class="form-group-ems mb-4">
            <label class="form-label-ems">Location / Area *</label>
            <input type="text" name="location" class="form-control-ems" placeholder="e.g. Baghdad-ul-Jadeed Campus" required>
          </div>

          <div class="row g-3 mb-4">
            <div class="col-md-8 form-group-ems mb-0">
              <label class="form-label-ems">Full Address</label>
              <input type="text" name="address" class="form-control-ems">
            </div>
            <div class="col-md-4 form-group-ems mb-0">
              <label class="form-label-ems">City</label>
              <input type="text" name="city" class="form-control-ems" value="Bahawalpur">
            </div>
          </div>

          <div class="form-group-ems mb-4">
            <label class="form-label-ems">Description</label>
            <textarea name="description" class="form-control-ems" rows="3"></textarea>
          </div>

          <div class="form-group-ems mb-4">
            <label class="form-label-ems">Amenities</label>
            <input type="text" name="amenities" class="form-control-ems" placeholder="Comma separated (AC, Projector, WiFi)">
          </div>

          <div class="row g-3 mb-4 border-top border-glass pt-4">
            <div class="col-md-6 form-group-ems mb-0">
              <label class="form-label-ems">Contact Person</label>
              <input type="text" name="contact_person" class="form-control-ems">
            </div>
            <div class="col-md-6 form-group-ems mb-0">
              <label class="form-label-ems">Contact Phone</label>
              <input type="text" name="contact_phone" class="form-control-ems">
            </div>
          </div>

          <div class="form-check mb-4">
            <input class="form-check-input bg-input border-glass" type="checkbox" name="availability" id="availCheck" checked style="accent-color:var(--purple)">
            <label class="form-check-label text-secondary" for="availCheck">
              Venue is currently available for bookings
            </label>
          </div>

          <button type="submit" class="btn-ems btn-primary-ems w-100 justify-content-center">
            <i class="bi bi-save me-1"></i> Save Venue
          </button>
        </form>
      </div>

    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
