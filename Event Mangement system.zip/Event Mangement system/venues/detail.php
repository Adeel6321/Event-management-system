<?php
/**
 * EMS — Venue Detail View
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect(SITE_URL . '/venues/index.php');

$stmt = $pdo->prepare("SELECT * FROM venues WHERE id = ?");
$stmt->execute([$id]);
$venue = $stmt->fetch();

if (!$venue) {
    setFlash('danger', 'Venue not found.');
    redirect(SITE_URL . '/venues/index.php');
}

// Fetch upcoming events at this venue
$stmt = $pdo->prepare("SELECT id, title, date, time, type FROM events WHERE venue_id = ? AND date >= CURDATE() AND status = 'published' ORDER BY date ASC LIMIT 5");
$stmt->execute([$id]);
$upcomingEvents = $stmt->fetchAll();

$pageTitle  = $venue['name'] . ' — Venue';
$activePage = 'venues';

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
  <div class="page-breadcrumb mb-3 scroll-animate">
    <a href="<?= SITE_URL ?>/index.php">Home</a> / 
    <a href="<?= SITE_URL ?>/venues/index.php">Venues</a> / 
    <span class="text-primary"><?= e($venue['name']) ?></span>
  </div>

  <div class="card-ems p-0 overflow-hidden mb-5 scroll-animate border-purple">
    <div class="bg-mesh" style="opacity:0.3;z-index:0"></div>
    <div class="position-relative p-4 p-md-5" style="z-index:1;background:rgba(15,23,42,0.6)">
      <div class="d-flex align-items-center gap-3 mb-3">
        <div class="stat-icon gold" style="width:56px;height:56px;font-size:1.4rem">
          <i class="bi bi-building"></i>
        </div>
        <div>
          <h1 class="page-title mb-1"><?= e($venue['name']) ?></h1>
          <div class="text-secondary"><i class="bi bi-geo-alt text-purple me-1"></i><?= e($venue['location']) ?><?= $venue['city'] ? ', '.e($venue['city']) : '' ?></div>
        </div>
      </div>
    </div>
  </div>

  <div class="row g-5">
    <div class="col-lg-8 scroll-animate">
      
      <div class="card-ems p-4 mb-4">
        <h4 class="mb-3 border-bottom border-glass pb-2">About this Venue</h4>
        <p class="text-secondary" style="line-height:1.8">
          <?= nl2br(e($venue['description'] ?: 'No description provided.')) ?>
        </p>

        <?php if($venue['amenities']): ?>
        <h5 class="mt-4 mb-3">Amenities</h5>
        <div class="d-flex flex-wrap gap-2">
          <?php foreach(explode(',', $venue['amenities']) as $am): ?>
            <span class="badge" style="background:rgba(124,58,237,.1);color:var(--purple-light);border:1px solid rgba(124,58,237,.3);font-size:.85rem;padding:6px 12px">
              <i class="bi bi-check2 text-success me-1"></i><?= e(trim($am)) ?>
            </span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <div class="card-ems p-4 mb-4">
        <h4 class="mb-3 border-bottom border-glass pb-2">Location Map</h4>
        <div class="rounded-ems overflow-hidden" style="background:var(--bg-input);height:300px;display:flex;align-items:center;justify-content:center;border:1px solid var(--border-glass)">
          <!-- Google Maps Iframe (Static mock for now, can be replaced with real embed based on address) -->
          <iframe 
            width="100%" 
            height="100%" 
            frameborder="0" 
            scrolling="no" 
            marginheight="0" 
            marginwidth="0" 
            src="https://maps.google.com/maps?q=<?= urlencode($venue['name'] . ', ' . $venue['city']) ?>&t=&z=13&ie=UTF8&iwloc=&output=embed"
            style="filter: invert(90%) hue-rotate(180deg);">
          </iframe>
        </div>
        <div class="mt-3 text-secondary text-center" style="font-size:.85rem">
          <i class="bi bi-pin-map-fill text-gold me-1"></i>
          <?= e($venue['address'] ?: $venue['location']) ?>
        </div>
      </div>

    </div>

    <div class="col-lg-4 scroll-animate">
      
      <!-- Quick Info -->
      <div class="card-ems p-4 mb-4">
        <h5 class="mb-3">Quick Info</h5>
        <ul class="list-unstyled mb-0" style="font-size:.9rem">
          <li class="d-flex align-items-center justify-content-between mb-3 border-bottom border-glass pb-2">
            <span class="text-muted"><i class="bi bi-people me-2"></i>Capacity</span>
            <span class="fw-bold text-primary"><?= number_format($venue['capacity']) ?></span>
          </li>
          <li class="d-flex align-items-center justify-content-between mb-3 border-bottom border-glass pb-2">
            <span class="text-muted"><i class="bi bi-shield-check me-2"></i>Status</span>
            <?php if($venue['availability']): ?>
              <span class="badge badge-success">Available</span>
            <?php else: ?>
              <span class="badge badge-danger">Unavailable</span>
            <?php endif; ?>
          </li>
          <?php if($venue['contact_person']): ?>
          <li class="d-flex flex-column mb-3 border-bottom border-glass pb-2">
            <span class="text-muted mb-1"><i class="bi bi-person-badge me-2"></i>Contact Person</span>
            <span class="fw-bold text-primary ms-4"><?= e($venue['contact_person']) ?></span>
          </li>
          <?php endif; ?>
          <?php if($venue['contact_phone']): ?>
          <li class="d-flex flex-column pb-1">
            <span class="text-muted mb-1"><i class="bi bi-telephone me-2"></i>Phone</span>
            <span class="fw-bold text-primary ms-4"><?= e($venue['contact_phone']) ?></span>
          </li>
          <?php endif; ?>
        </ul>
      </div>

      <!-- Upcoming Events -->
      <div class="card-ems p-4 mb-4">
        <h5 class="mb-3 border-bottom border-glass pb-2">Upcoming Events Here</h5>
        <?php if(empty($upcomingEvents)): ?>
          <div class="text-muted text-center py-3" style="font-size:.85rem">
            No upcoming events at this venue.
          </div>
        <?php else: ?>
          <div class="d-flex flex-column gap-3">
            <?php foreach($upcomingEvents as $ev): ?>
              <a href="<?= SITE_URL ?>/events/detail.php?id=<?= $ev['id'] ?>" class="d-block p-2 rounded-ems" style="background:rgba(255,255,255,.02);border:1px solid var(--border-glass);transition:var(--t-fast);text-decoration:none">
                <div class="fw-bold text-primary mb-1" style="font-size:.9rem"><?= e($ev['title']) ?></div>
                <div class="d-flex justify-content-between text-muted" style="font-size:.75rem">
                  <span><i class="bi bi-calendar me-1"></i><?= date('M d', strtotime($ev['date'])) ?></span>
                  <span class="badge badge-<?= $ev['type']==='free' ? 'success' : 'warning' ?>"><?= ucfirst($ev['type']) ?></span>
                </div>
              </a>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
