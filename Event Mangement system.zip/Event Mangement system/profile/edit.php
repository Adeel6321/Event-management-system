<?php
/**
 * EMS — Edit Profile
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireLogin();

$pageTitle = 'Edit Profile';
$sessionUser = currentUser();
$errors    = [];

// Fetch latest user data from DB
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$sessionUser['id']]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request.';
    } else {
        $name  = $_POST['name'] ?? '';
        $phone = $_POST['phone'] ?? '';
        
        if (empty($name)) {
            $errors[] = 'Name is required.';
        }

        $imagePath = $user['profile_image'];
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
            $upload = uploadImage($_FILES['profile_image'], 'profiles');
            if ($upload) {
                $imagePath = $upload;
            } else {
                $errors[] = 'Failed to upload profile image. Ensure it is a valid image under 5MB.';
            }
        }

        if (empty($errors)) {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, profile_image = ? WHERE id = ?");
            if ($stmt->execute([$name, $phone, $imagePath, $user['id']])) {
                $_SESSION['user_name'] = $name; // update session
                setFlash('success', 'Profile updated successfully.');
                redirect(SITE_URL . '/profile/edit.php');
            } else {
                $errors[] = 'Failed to update profile.';
            }
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    if (verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if (!password_verify($current, $user['password'])) {
            $errors[] = 'Current password is incorrect.';
        } elseif (strlen($new) < 8) {
            $errors[] = 'New password must be at least 8 characters.';
        } elseif ($new !== $confirm) {
            $errors[] = 'New passwords do not match.';
        } else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $user['id']]);
            setFlash('success', 'Password changed successfully.');
            redirect(SITE_URL . '/profile/edit.php');
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-8 scroll-animate">
      
      <h1 class="page-title mb-4">My Profile</h1>

      <?php if (!empty($errors)): ?>
        <div class="alert-custom alert-danger mb-4">
          <ul class="mb-0 ps-3">
            <?php foreach ($errors as $e) echo "<li>" . e($e) . "</li>"; ?>
          </ul>
        </div>
      <?php endif; ?>

      <div class="card-ems p-4 mb-4">
        <h5 class="mb-4">Personal Information</h5>
        <form method="POST" action="" enctype="multipart/form-data">
          <?= csrfField() ?>
          <input type="hidden" name="update_profile" value="1">
          
          <div class="d-flex align-items-center gap-4 mb-4 pb-4 border-bottom border-glass">
            <div class="avatar-circle" style="width:80px;height:80px;font-size:2.5rem;overflow:hidden">
              <?php if($user['profile_image']): ?>
                <img src="<?= SITE_URL ?>/assets/uploads/<?= e($user['profile_image']) ?>" alt="Profile" style="width:100%;height:100%;object-fit:cover">
              <?php else: ?>
                <?= strtoupper(substr($user['name'],0,1)) ?>
              <?php endif; ?>
            </div>
            <div>
              <label class="form-label-ems d-block">Profile Image</label>
              <input type="file" name="profile_image" class="form-control-ems" accept="image/jpeg,image/png,image/webp,image/gif">
              <div class="text-muted mt-1" style="font-size:.75rem">Max size: 5MB. Formats: JPG, PNG, GIF, WEBP.</div>
            </div>
          </div>
          
          <div class="form-group-ems">
            <label class="form-label-ems">Email (Cannot be changed)</label>
            <input type="email" class="form-control-ems text-muted" value="<?= e($user['email']) ?>" disabled>
          </div>

          <div class="form-group-ems">
            <label class="form-label-ems">Role</label>
            <input type="text" class="form-control-ems text-muted" value="<?= ucfirst($user['role']) ?>" disabled>
          </div>

          <div class="form-group-ems">
            <label class="form-label-ems">Full Name</label>
            <input type="text" name="name" class="form-control-ems" value="<?= e($user['name']) ?>" required>
          </div>

          <div class="form-group-ems mb-4">
            <label class="form-label-ems">Phone Number</label>
            <input type="text" name="phone" class="form-control-ems" value="<?= e($user['phone']) ?>">
          </div>

          <button type="submit" class="btn-ems btn-primary-ems"><i class="bi bi-save me-1"></i> Update Profile</button>
        </form>
      </div>

      <div class="card-ems p-4">
        <h5 class="mb-4">Change Password</h5>
        <form method="POST" action="">
          <?= csrfField() ?>
          <input type="hidden" name="change_password" value="1">
          
          <div class="form-group-ems">
            <label class="form-label-ems">Current Password</label>
            <input type="password" name="current_password" class="form-control-ems" required>
          </div>
          
          <div class="form-group-ems">
            <label class="form-label-ems">New Password</label>
            <input type="password" name="new_password" class="form-control-ems" required minlength="8">
          </div>
          
          <div class="form-group-ems mb-4">
            <label class="form-label-ems">Confirm New Password</label>
            <input type="password" name="confirm_password" class="form-control-ems" required minlength="8">
          </div>

          <button type="submit" class="btn-ems btn-gold-ems"><i class="bi bi-key me-1"></i> Change Password</button>
        </form>
      </div>

    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
