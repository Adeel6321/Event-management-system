<?php
/**
 * EMS — 404 Error Page
 */
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Page Not Found';
require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-5 text-center" style="min-height: 70vh; display: flex; flex-direction: column; justify-content: center; align-items: center;">
    <div style="font-size: 8rem; line-height: 1; font-family: 'Outfit', sans-serif; font-weight: 800; background: linear-gradient(135deg, var(--purple-light), var(--gold)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 1rem;">
        404
    </div>
    <h2 class="mb-3">Oops! Page not found.</h2>
    <p class="text-muted mb-4" style="max-width: 500px;">
        The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
    </p>
    <a href="<?= SITE_URL ?>/index.php" class="btn-ems btn-primary-ems">
        <i class="bi bi-house-door-fill"></i> Back to Home
    </a>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
