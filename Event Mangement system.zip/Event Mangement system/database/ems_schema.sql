-- ===================================================
-- Event Management System (EMS) — Database Schema
-- Institution: IUB, Department of Information Technology
-- Developer: Muhammad Adeel Jameel
-- Supervisor: Ms. Sara Fareed
-- Version: 1.0
-- ===================================================

CREATE DATABASE IF NOT EXISTS ems_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ems_db;

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = '';

-- Drop existing tables for clean reinstall
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS venues;
DROP TABLE IF EXISTS password_resets;
DROP TABLE IF EXISTS login_attempts;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- ===================================================
-- TABLE: users
-- ===================================================
CREATE TABLE users (
    id            INT          PRIMARY KEY AUTO_INCREMENT,
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(150) UNIQUE NOT NULL,
    password      VARCHAR(255) NOT NULL,
    phone         VARCHAR(20)  DEFAULT NULL,
    role          ENUM('admin','organizer','attendee') DEFAULT 'attendee',
    email_verified TINYINT(1)  DEFAULT 0,
    verification_token VARCHAR(100) DEFAULT NULL,
    profile_image VARCHAR(255) DEFAULT NULL,
    is_active     TINYINT(1)   DEFAULT 1,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================
-- TABLE: login_attempts (brute-force protection)
-- ===================================================
CREATE TABLE login_attempts (
    id           INT         PRIMARY KEY AUTO_INCREMENT,
    email        VARCHAR(150) NOT NULL,
    ip_address   VARCHAR(45) DEFAULT NULL,
    attempts     INT         DEFAULT 1,
    locked_until TIMESTAMP   NULL DEFAULT NULL,
    last_attempt TIMESTAMP   DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_ip (ip_address)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================
-- TABLE: password_resets
-- ===================================================
CREATE TABLE password_resets (
    id         INT          PRIMARY KEY AUTO_INCREMENT,
    email      VARCHAR(150) NOT NULL,
    token      VARCHAR(100) NOT NULL,
    expires_at TIMESTAMP    NOT NULL,
    used       TINYINT(1)   DEFAULT 0,
    created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_token (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================
-- TABLE: venues
-- ===================================================
CREATE TABLE venues (
    id              INT          PRIMARY KEY AUTO_INCREMENT,
    name            VARCHAR(150) NOT NULL,
    location        VARCHAR(255) NOT NULL,
    address         TEXT         DEFAULT NULL,
    city            VARCHAR(100) DEFAULT 'Bahawalpur',
    capacity        INT          NOT NULL DEFAULT 100,
    description     TEXT         DEFAULT NULL,
    images          VARCHAR(500) DEFAULT NULL,
    amenities       TEXT         DEFAULT NULL,
    contact_person  VARCHAR(100) DEFAULT NULL,
    contact_phone   VARCHAR(20)  DEFAULT NULL,
    availability    TINYINT(1)   DEFAULT 1,
    created_by      INT          DEFAULT NULL,
    created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================
-- TABLE: events
-- ===================================================
CREATE TABLE events (
    id            INT          PRIMARY KEY AUTO_INCREMENT,
    title         VARCHAR(200) NOT NULL,
    description   TEXT         DEFAULT NULL,
    date          DATE         NOT NULL,
    time          TIME         NOT NULL,
    end_date      DATE         DEFAULT NULL,
    end_time      TIME         DEFAULT NULL,
    venue_id      INT          DEFAULT NULL,
    category      ENUM('conference','wedding','music','sports','cultural','corporate','seminar','other') DEFAULT 'other',
    type          ENUM('free','paid') DEFAULT 'free',
    status        ENUM('draft','published','cancelled','completed') DEFAULT 'draft',
    organizer_id  INT          DEFAULT NULL,
    ticket_price  DECIMAL(10,2) DEFAULT 0.00,
    capacity      INT          DEFAULT 100,
    registered    INT          DEFAULT 0,
    banner_image  VARCHAR(255) DEFAULT NULL,
    tags          VARCHAR(500) DEFAULT NULL,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (venue_id)     REFERENCES venues(id) ON DELETE SET NULL,
    FOREIGN KEY (organizer_id) REFERENCES users(id)  ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================
-- TABLE: bookings
-- ===================================================
CREATE TABLE bookings (
    id                 INT          PRIMARY KEY AUTO_INCREMENT,
    user_id            INT          NOT NULL,
    event_id           INT          NOT NULL,
    quantity           INT          DEFAULT 1,
    total_price        DECIMAL(10,2) DEFAULT 0.00,
    status             ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
    booking_reference  VARCHAR(20)  UNIQUE,
    notes              TEXT         DEFAULT NULL,
    created_at         TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_event (user_id, event_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================
-- TABLE: notifications
-- ===================================================
CREATE TABLE notifications (
    id       INT          PRIMARY KEY AUTO_INCREMENT,
    user_id  INT          NOT NULL,
    title    VARCHAR(200) NOT NULL DEFAULT 'Notification',
    message  TEXT         NOT NULL,
    type     ENUM('booking','cancellation','reminder','update','system') DEFAULT 'system',
    status   ENUM('unread','read') DEFAULT 'unread',
    link     VARCHAR(255) DEFAULT NULL,
    sent_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_status (user_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================
-- TABLE: reviews
-- ===================================================
CREATE TABLE reviews (
    id         INT      PRIMARY KEY AUTO_INCREMENT,
    user_id    INT      NOT NULL,
    event_id   INT      NOT NULL,
    rating     TINYINT  NOT NULL,
    comment    TEXT     DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_event_review (user_id, event_id),
    CONSTRAINT chk_rating CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================
-- SEED DATA — Venues
-- ===================================================
INSERT INTO venues (name, location, address, city, capacity, description, amenities, contact_person, contact_phone, availability) VALUES
('IUB Convention Center', 'Baghdad-ul-Jadeed Campus', 'Baghdad-ul-Jadeed Campus, Bahawalpur', 'Bahawalpur', 1000, 'State-of-the-art convention center with modern facilities for large-scale corporate and cultural events.', 'AC, Stage, Sound System, Projector, Parking, WiFi, Green Room, Catering Area', 'Mr. Ahmed Ali', '0300-1234567', 1),
('IT Department Auditorium', 'Abbasia Campus, IUB', 'Abbasia Campus, Bahawalpur', 'Bahawalpur', 300, 'Modern auditorium equipped for seminars, workshops, and academic events with latest AV equipment.', 'AC, Projector, Sound System, WiFi, Whiteboard, Video Conferencing', 'Ms. Sara Fareed', '0301-9876543', 1),
('Sports Complex Hall', 'Baghdad-ul-Jadeed Campus, IUB', 'Baghdad-ul-Jadeed Campus, Bahawalpur', 'Bahawalpur', 500, 'Multi-purpose hall suitable for sports events, cultural programs, and ceremonies.', 'AC, Sports Facilities, Open Ground, Parking, Changing Rooms', 'Mr. Khalid Mahmood', '0303-5554321', 1),
('City Garden Venue', 'Model Town, Bahawalpur', 'Model Town, Near Derawar Chowk, Bahawalpur', 'Bahawalpur', 800, 'Beautiful outdoor venue with lush green garden, ideal for weddings and cultural gatherings.', 'Garden, Stage, Seating, Catering, Decorations, Parking, Generator Backup', 'Mr. Tariq Hassan', '0321-7891234', 1);

-- ===================================================
-- NOTE: Run setup.php to create admin + sample events
-- Admin credentials: admin@ems.com / Admin@123
-- ===================================================
