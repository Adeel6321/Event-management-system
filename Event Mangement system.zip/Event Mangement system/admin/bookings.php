<?php
/**
 * EMS — Admin Bookings Management
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();

$pageTitle  = 'Manage Bookings';
$activePage = 'admin';

// Search
$search = $_GET['q'] ?? '';
$where = "1=1";
$params = [];
if ($search) {
    $where .= " AND (b.booking_reference LIKE ? OR u.name LIKE ? OR e.title LIKE ?)";
    $term = "%$search%";
    $params = [$term, $term, $term];
}

$stmt = $pdo->prepare("
    SELECT b.*, u.name AS user_name, u.email, e.title AS event_title, e.date 
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN events e ON b.event_id = e.id
    WHERE $where
    ORDER BY b.created_at DESC
");
$stmt->execute($params);
$bookings = $stmt->fetchAll();

// Handle cancellation from admin side
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_booking_id'])) {
    if (verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $bid = (int)$_POST['cancel_booking_id'];
        
        // Fetch to adjust event capacity
        $bStmt = $pdo->prepare("SELECT event_id, quantity, status FROM bookings WHERE id = ?");
        $bStmt->execute([$bid]);
        $bk = $bStmt->fetch();

        if ($bk && $bk['status'] !== 'cancelled') {
            $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?")->execute([$bid]);
            $pdo->prepare("UPDATE events SET registered = registered - ? WHERE id = ?")->execute([$bk['quantity'], $bk['event_id']]);
            setFlash('success', 'Booking cancelled by admin.');
        }
        redirect(SITE_URL . '/admin/bookings.php');
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-wrapper">
  <!-- Sidebar -->
  <aside class="admin-sidebar" id="adminSidebar">
    <a href="<?= SITE_URL ?>/index.php" class="sidebar-logo">
      <div class="brand-icon" style="width:28px;height:28px;font-size:.9rem">🎫</div>
      <div class="sidebar-logo-text">EMS<span>·Admin</span></div>
    </a>
    
    <div class="sidebar-section">Overview</div>
    <a href="dashboard.php" class="sidebar-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    
    <div class="sidebar-section">Management</div>
    <a href="users.php" class="sidebar-link"><i class="bi bi-people"></i> Users</a>
    <a href="events.php" class="sidebar-link"><i class="bi bi-calendar-event"></i> Events</a>
    <a href="venues.php" class="sidebar-link"><i class="bi bi-building"></i> Venues</a>
    <a href="bookings.php" class="sidebar-link active"><i class="bi bi-ticket-perforated"></i> Bookings</a>
    
    <div class="sidebar-section">Data</div>
    <a href="reports.php" class="sidebar-link"><i class="bi bi-bar-chart"></i> Reports</a>
    
    <div class="sidebar-footer">
      <a href="<?= SITE_URL ?>/auth/logout.php" class="sidebar-link" style="color:var(--red)"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
  </aside>

  <!-- Content -->
  <main class="admin-content scroll-animate">
    <div class="admin-topbar">
      <div>
        <h1 class="page-title mb-0">Manage Bookings</h1>
        <div class="page-breadcrumb"><a href="dashboard.php">Admin</a> / Bookings</div>
      </div>
      <button class="sidebar-toggle" id="sidebarToggle"><i class="bi bi-list"></i></button>
    </div>

    <div class="card-ems p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <form action="" method="GET" class="search-bar" style="max-width:300px;margin:0">
          <i class="bi bi-search text-muted px-2"></i>
          <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search reference, user...">
        </form>
        <span class="badge badge-purple"><?= count($bookings) ?> Bookings</span>
      </div>

      <div class="table-responsive">
        <table class="table-ems" id="searchableTable">
          <thead>
            <tr>
              <th>Ref</th>
              <th>User</th>
              <th>Event</th>
              <th>Qty</th>
              <th>Total (PKR)</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($bookings as $b): ?>
            <tr>
              <td class="td-primary" style="font-family:monospace"><?= e($b['booking_reference']) ?></td>
              <td>
                <div style="font-weight:600"><?= e($b['user_name']) ?></div>
                <div style="font-size:.75rem;color:var(--text-muted)"><?= e($b['email']) ?></div>
              </td>
              <td>
                <div style="font-weight:600"><?= e(mb_strimwidth($b['event_title'],0,30,'...')) ?></div>
                <div style="font-size:.75rem;color:var(--text-muted)"><?= formatDate($b['date']) ?></div>
              </td>
              <td><?= $b['quantity'] ?></td>
              <td class="text-gold"><?= number_format($b['total_price']) ?></td>
              <td><?= statusBadge($b['status']) ?></td>
              <td>
                <?php if($b['status'] !== 'cancelled'): ?>
                <form action="" method="POST" style="display:inline">
                  <?= csrfField() ?>
                  <input type="hidden" name="cancel_booking_id" value="<?= $b['id'] ?>">
                  <button type="submit" class="btn-ems btn-ghost-ems px-2 py-1 text-danger" style="font-size:.75rem"
                          data-confirm="Force cancel this booking?">
                    <i class="bi bi-x-circle me-1"></i>Cancel
                  </button>
                </form>
                <?php else: ?>
                  <span class="text-muted" style="font-size:.75rem">Cancelled</span>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($bookings)): ?>
            <tr><td colspan="7" class="text-center py-4 text-muted">No bookings found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
