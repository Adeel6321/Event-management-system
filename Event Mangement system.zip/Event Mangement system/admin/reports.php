<?php
/**
 * EMS — Admin Reports
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();

$pageTitle  = 'Reports';
$activePage = 'admin';

// Booking Status Breakdown
$statusCounts = $pdo->query("SELECT status, COUNT(*) as count FROM bookings GROUP BY status")->fetchAll();

// Revenue per Event (Top 5)
$revenuePerEvent = $pdo->query("
    SELECT e.title, SUM(b.total_price) as revenue, COUNT(b.id) as tickets
    FROM events e
    LEFT JOIN bookings b ON e.id = b.event_id AND b.status = 'confirmed'
    WHERE e.type = 'paid'
    GROUP BY e.id
    ORDER BY revenue DESC
    LIMIT 5
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-wrapper">
  <!-- Sidebar -->
  <aside class="admin-sidebar" id="adminSidebar">
    <a href="<?= SITE_URL ?>/index.php" class="sidebar-logo">
      <div class="brand-icon" style="width:28px;height:28px;font-size:.9rem">🎫</div>
      <div class="sidebar-logo-text">EMS<span>·Admin</span></div>
    </a>
    
    <div class="sidebar-section">Overview</div>
    <a href="dashboard.php" class="sidebar-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    
    <div class="sidebar-section">Management</div>
    <a href="users.php" class="sidebar-link"><i class="bi bi-people"></i> Users</a>
    <a href="events.php" class="sidebar-link"><i class="bi bi-calendar-event"></i> Events</a>
    <a href="venues.php" class="sidebar-link"><i class="bi bi-building"></i> Venues</a>
    <a href="bookings.php" class="sidebar-link"><i class="bi bi-ticket-perforated"></i> Bookings</a>
    
    <div class="sidebar-section">Data</div>
    <a href="reports.php" class="sidebar-link active"><i class="bi bi-bar-chart"></i> Reports</a>
    
    <div class="sidebar-footer">
      <a href="<?= SITE_URL ?>/auth/logout.php" class="sidebar-link" style="color:var(--red)"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
  </aside>

  <!-- Content -->
  <main class="admin-content scroll-animate">
    <div class="admin-topbar">
      <div>
        <h1 class="page-title mb-0">Reports & Analytics</h1>
        <div class="page-breadcrumb"><a href="dashboard.php">Admin</a> / Reports</div>
      </div>
      <button class="sidebar-toggle" id="sidebarToggle"><i class="bi bi-list"></i></button>
    </div>

    <div class="row g-4">
      
      <!-- Top Revenue Events -->
      <div class="col-lg-8">
        <div class="card-ems p-4 h-100">
          <h5 class="mb-4">Top Revenue Generating Events</h5>
          <div class="table-responsive">
            <table class="table-ems">
              <thead>
                <tr>
                  <th>Event Title</th>
                  <th>Tickets Sold</th>
                  <th>Revenue (PKR)</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach($revenuePerEvent as $rev): ?>
                <tr>
                  <td class="td-primary"><?= e($rev['title']) ?></td>
                  <td><?= $rev['tickets'] ?></td>
                  <td class="text-gold fw-bold"><?= number_format($rev['revenue'] ?: 0) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($revenuePerEvent)): ?>
                <tr><td colspan="3" class="text-center text-muted">No paid events data yet.</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Booking Status -->
      <div class="col-lg-4">
        <div class="card-ems p-4 h-100">
          <h5 class="mb-4">Booking Status</h5>
          <ul class="list-unstyled">
            <?php foreach($statusCounts as $sc): ?>
            <li class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom border-glass">
              <span class="text-secondary"><?= ucfirst($sc['status']) ?></span>
              <span class="badge badge-purple"><?= $sc['count'] ?></span>
            </li>
            <?php endforeach; ?>
          </ul>
          <div class="mt-4 pt-3 text-center border-top border-glass">
            <button class="btn-ems btn-outline-ems btn-sm-ems" onclick="window.print()"><i class="bi bi-printer"></i> Print Report</button>
          </div>
        </div>
      </div>

    </div>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
