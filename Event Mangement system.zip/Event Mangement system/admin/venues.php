<?php
/**
 * EMS — Admin Venue Management
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();

$pageTitle  = 'Manage Venues';
$activePage = 'admin';

// Search
$search = $_GET['q'] ?? '';
$where = "1=1";
$params = [];
if ($search) {
    $where .= " AND (name LIKE ? OR city LIKE ?)";
    $term = "%$search%";
    $params = [$term, $term];
}

$stmt = $pdo->prepare("SELECT * FROM venues WHERE $where ORDER BY name ASC");
$stmt->execute($params);
$venues = $stmt->fetchAll();

// Handle status toggle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_venue_id'])) {
    if (verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $vid = (int)$_POST['toggle_venue_id'];
        $pdo->prepare("UPDATE venues SET availability = NOT availability WHERE id = ?")->execute([$vid]);
        setFlash('success', 'Venue availability updated.');
        redirect(SITE_URL . '/admin/venues.php');
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-wrapper">
  <!-- Sidebar -->
  <aside class="admin-sidebar" id="adminSidebar">
    <a href="<?= SITE_URL ?>/index.php" class="sidebar-logo">
      <div class="brand-icon" style="width:28px;height:28px;font-size:.9rem">🎫</div>
      <div class="sidebar-logo-text">EMS<span>·Admin</span></div>
    </a>
    
    <div class="sidebar-section">Overview</div>
    <a href="dashboard.php" class="sidebar-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    
    <div class="sidebar-section">Management</div>
    <a href="users.php" class="sidebar-link"><i class="bi bi-people"></i> Users</a>
    <a href="events.php" class="sidebar-link"><i class="bi bi-calendar-event"></i> Events</a>
    <a href="venues.php" class="sidebar-link active"><i class="bi bi-building"></i> Venues</a>
    <a href="bookings.php" class="sidebar-link"><i class="bi bi-ticket-perforated"></i> Bookings</a>
    
    <div class="sidebar-section">Data</div>
    <a href="reports.php" class="sidebar-link"><i class="bi bi-bar-chart"></i> Reports</a>
    
    <div class="sidebar-footer">
      <a href="<?= SITE_URL ?>/auth/logout.php" class="sidebar-link" style="color:var(--red)"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
  </aside>

  <!-- Content -->
  <main class="admin-content scroll-animate">
    <div class="admin-topbar">
      <div>
        <h1 class="page-title mb-0">Manage Venues</h1>
        <div class="page-breadcrumb"><a href="dashboard.php">Admin</a> / Venues</div>
      </div>
      <div class="d-flex gap-2">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="bi bi-list"></i></button>
        <a href="<?= SITE_URL ?>/venues/add.php" class="btn-ems btn-primary-ems btn-sm-ems"><i class="bi bi-plus-lg"></i> Add Venue</a>
      </div>
    </div>

    <div class="card-ems p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <form action="" method="GET" class="search-bar" style="max-width:300px;margin:0">
          <i class="bi bi-search text-muted px-2"></i>
          <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search venues...">
        </form>
        <span class="badge badge-purple"><?= count($venues) ?> Venues</span>
      </div>

      <div class="table-responsive">
        <table class="table-ems" id="searchableTable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Venue Name</th>
              <th>City</th>
              <th>Capacity</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($venues as $v): ?>
            <tr>
              <td>#<?= $v['id'] ?></td>
              <td class="td-primary">
                <i class="bi bi-building text-purple me-2"></i><?= e($v['name']) ?>
              </td>
              <td><?= e($v['city']) ?></td>
              <td><?= number_format($v['capacity']) ?></td>
              <td>
                <?php if($v['availability']): ?>
                  <span class="badge badge-success">Available</span>
                <?php else: ?>
                  <span class="badge badge-danger">Unavailable</span>
                <?php endif; ?>
              </td>
              <td>
                <form action="" method="POST" style="display:inline">
                  <?= csrfField() ?>
                  <input type="hidden" name="toggle_venue_id" value="<?= $v['id'] ?>">
                  <button type="submit" class="btn-ems btn-ghost-ems px-2 py-1" style="font-size:.75rem">
                    <?= $v['availability'] ? '<i class="bi bi-slash-circle text-danger me-1"></i>Disable' : '<i class="bi bi-check-circle text-success me-1"></i>Enable' ?>
                  </button>
                </form>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($venues)): ?>
            <tr><td colspan="6" class="text-center py-4 text-muted">No venues found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
