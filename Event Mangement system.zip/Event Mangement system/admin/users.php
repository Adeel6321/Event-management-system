<?php
/**
 * EMS — Admin User Management
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();

$pageTitle  = 'Manage Users';
$activePage = 'admin';

// Search
$search = $_GET['q'] ?? '';
$where = "1=1";
$params = [];
if ($search) {
    $where .= " AND (name LIKE ? OR email LIKE ?)";
    $term = "%$search%";
    $params = [$term, $term];
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE $where ORDER BY created_at DESC");
$stmt->execute($params);
$users = $stmt->fetchAll();

// Handle status toggle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_user_id'])) {
    if (verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $uid = (int)$_POST['toggle_user_id'];
        if ($uid !== $_SESSION['user_id']) { // Can't toggle self
            $pdo->prepare("UPDATE users SET is_active = NOT is_active WHERE id = ?")->execute([$uid]);
            setFlash('success', 'User status updated.');
        } else {
            setFlash('danger', 'You cannot deactivate your own account.');
        }
        redirect(SITE_URL . '/admin/users.php');
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-wrapper">
  <!-- Sidebar -->
  <aside class="admin-sidebar" id="adminSidebar">
    <a href="<?= SITE_URL ?>/index.php" class="sidebar-logo">
      <div class="brand-icon" style="width:28px;height:28px;font-size:.9rem">🎫</div>
      <div class="sidebar-logo-text">EMS<span>·Admin</span></div>
    </a>
    
    <div class="sidebar-section">Overview</div>
    <a href="dashboard.php" class="sidebar-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    
    <div class="sidebar-section">Management</div>
    <a href="users.php" class="sidebar-link active"><i class="bi bi-people"></i> Users</a>
    <a href="events.php" class="sidebar-link"><i class="bi bi-calendar-event"></i> Events</a>
    <a href="venues.php" class="sidebar-link"><i class="bi bi-building"></i> Venues</a>
    <a href="bookings.php" class="sidebar-link"><i class="bi bi-ticket-perforated"></i> Bookings</a>
    
    <div class="sidebar-section">Data</div>
    <a href="reports.php" class="sidebar-link"><i class="bi bi-bar-chart"></i> Reports</a>
    
    <div class="sidebar-footer">
      <a href="<?= SITE_URL ?>/auth/logout.php" class="sidebar-link" style="color:var(--red)"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
  </aside>

  <!-- Content -->
  <main class="admin-content scroll-animate">
    <div class="admin-topbar">
      <div>
        <h1 class="page-title mb-0">Manage Users</h1>
        <div class="page-breadcrumb"><a href="dashboard.php">Admin</a> / Users</div>
      </div>
      <button class="sidebar-toggle" id="sidebarToggle"><i class="bi bi-list"></i></button>
    </div>

    <div class="card-ems p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <form action="" method="GET" class="search-bar" style="max-width:300px;margin:0">
          <i class="bi bi-search text-muted px-2"></i>
          <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search users...">
        </form>
        <span class="badge badge-purple"><?= count($users) ?> Users</span>
      </div>

      <div class="table-responsive">
        <table class="table-ems" id="searchableTable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
              <th>Joined</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
              <td>#<?= $u['id'] ?></td>
              <td class="td-primary">
                <div class="d-flex align-items-center gap-2">
                  <div class="avatar-circle" style="width:24px;height:24px;font-size:.65rem"><?= strtoupper(substr($u['name'],0,1)) ?></div>
                  <?= e($u['name']) ?>
                </div>
              </td>
              <td><?= e($u['email']) ?>
                <?php if($u['email_verified']): ?>
                  <i class="bi bi-check-circle-fill text-success" style="font-size:.7rem" title="Verified"></i>
                <?php endif; ?>
              </td>
              <td>
                <span class="badge <?= $u['role']==='admin' ? 'badge-danger' : ($u['role']==='organizer' ? 'badge-warning' : 'badge-secondary') ?>">
                  <?= ucfirst($u['role']) ?>
                </span>
              </td>
              <td>
                <?php if($u['is_active']): ?>
                  <span class="badge badge-success">Active</span>
                <?php else: ?>
                  <span class="badge badge-danger">Suspended</span>
                <?php endif; ?>
              </td>
              <td style="font-size:.8rem"><?= formatDate($u['created_at']) ?></td>
              <td>
                <?php if($u['id'] !== $_SESSION['user_id']): ?>
                <form action="" method="POST" style="display:inline">
                  <?= csrfField() ?>
                  <input type="hidden" name="toggle_user_id" value="<?= $u['id'] ?>">
                  <button type="submit" class="btn-ems btn-ghost-ems px-2 py-1" style="font-size:.75rem"
                          data-confirm="Toggle status for this user?">
                    <?= $u['is_active'] ? '<i class="bi bi-slash-circle text-danger me-1"></i>Suspend' : '<i class="bi bi-check-circle text-success me-1"></i>Activate' ?>
                  </button>
                </form>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($users)): ?>
            <tr><td colspan="7" class="text-center py-4 text-muted">No users found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
