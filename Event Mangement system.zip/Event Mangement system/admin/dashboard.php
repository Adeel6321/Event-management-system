<?php
/**
 * EMS — Admin Dashboard
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();

$pageTitle  = 'Admin Dashboard';
$activePage = 'admin';

// ─── Stats ──────────────────────────────────────────────────
$stats = [
    'users'    => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
    'events'   => $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn(),
    'venues'   => $pdo->query("SELECT COUNT(*) FROM venues")->fetchColumn(),
    'bookings' => $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn(),
    'revenue'  => $pdo->query("SELECT SUM(total_price) FROM bookings WHERE status='confirmed'")->fetchColumn() ?: 0,
];

// ─── Recent Bookings ─────────────────────────────────────────
$recentBookings = $pdo->query("
    SELECT b.id, b.booking_reference, b.created_at, b.status, b.total_price, 
           u.name AS user_name, e.title AS event_title
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN events e ON b.event_id = e.id
    ORDER BY b.created_at DESC LIMIT 5
")->fetchAll();

// ─── Upcoming Events ─────────────────────────────────────────
$upcomingEvents = $pdo->query("
    SELECT title, date, registered, capacity 
    FROM events 
    WHERE date >= CURDATE() AND status = 'published'
    ORDER BY date ASC LIMIT 5
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-wrapper">
  <!-- Sidebar -->
  <aside class="admin-sidebar" id="adminSidebar">
    <a href="<?= SITE_URL ?>/index.php" class="sidebar-logo">
      <div class="brand-icon" style="width:28px;height:28px;font-size:.9rem">🎫</div>
      <div class="sidebar-logo-text">EMS<span>·Admin</span></div>
    </a>
    
    <div class="sidebar-section">Overview</div>
    <a href="dashboard.php" class="sidebar-link active"><i class="bi bi-speedometer2"></i> Dashboard</a>
    
    <div class="sidebar-section">Management</div>
    <a href="users.php" class="sidebar-link"><i class="bi bi-people"></i> Users</a>
    <a href="events.php" class="sidebar-link"><i class="bi bi-calendar-event"></i> Events</a>
    <a href="venues.php" class="sidebar-link"><i class="bi bi-building"></i> Venues</a>
    <a href="bookings.php" class="sidebar-link"><i class="bi bi-ticket-perforated"></i> Bookings</a>
    
    <div class="sidebar-section">Data</div>
    <a href="reports.php" class="sidebar-link"><i class="bi bi-bar-chart"></i> Reports</a>
    
    <div class="sidebar-footer">
      <a href="<?= SITE_URL ?>/auth/logout.php" class="sidebar-link" style="color:var(--red)"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
  </aside>

  <!-- Content -->
  <main class="admin-content scroll-animate">
    <div class="admin-topbar">
      <div>
        <h1 class="page-title mb-0">Dashboard</h1>
        <div class="page-breadcrumb">Admin / Overview</div>
      </div>
      <button class="sidebar-toggle" id="sidebarToggle"><i class="bi bi-list"></i></button>
    </div>

    <!-- Stats Row -->
    <div class="row g-4 mb-5">
      <div class="col-xl-3 col-md-6">
        <div class="stat-card blue">
          <div class="stat-icon blue"><i class="bi bi-people"></i></div>
          <div>
            <div class="stat-number" data-counter data-target="<?= $stats['users'] ?>"><?= $stats['users'] ?></div>
            <div class="stat-label">Total Users</div>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-md-6">
        <div class="stat-card purple">
          <div class="stat-icon purple"><i class="bi bi-calendar-event"></i></div>
          <div>
            <div class="stat-number" data-counter data-target="<?= $stats['events'] ?>"><?= $stats['events'] ?></div>
            <div class="stat-label">Total Events</div>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-md-6">
        <div class="stat-card green">
          <div class="stat-icon green"><i class="bi bi-ticket-perforated"></i></div>
          <div>
            <div class="stat-number" data-counter data-target="<?= $stats['bookings'] ?>"><?= $stats['bookings'] ?></div>
            <div class="stat-label">Total Bookings</div>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-md-6">
        <div class="stat-card gold">
          <div class="stat-icon gold"><i class="bi bi-cash-stack"></i></div>
          <div>
            <div class="stat-number text-gold">PKR <?= number_format($stats['revenue']) ?></div>
            <div class="stat-label">Total Revenue</div>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-4">
      <!-- Recent Bookings -->
      <div class="col-lg-8">
        <div class="card-ems p-4 h-100">
          <div class="d-flex justify-content-between align-items-center mb-4">
            <h5 class="mb-0">Recent Bookings</h5>
            <a href="bookings.php" class="btn-ems btn-ghost-ems btn-sm-ems">View All</a>
          </div>
          <div class="table-responsive">
            <table class="table-ems">
              <thead>
                <tr>
                  <th>Ref</th>
                  <th>User</th>
                  <th>Event</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach($recentBookings as $b): ?>
                <tr>
                  <td class="td-primary"><?= $b['booking_reference'] ?></td>
                  <td><?= e($b['user_name']) ?></td>
                  <td><?= e(mb_strimwidth($b['event_title'], 0, 30, '...')) ?></td>
                  <td class="text-gold">PKR <?= number_format($b['total_price']) ?></td>
                  <td><?= statusBadge($b['status']) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($recentBookings)): ?>
                <tr><td colspan="5" class="text-center py-3 text-muted">No bookings yet.</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Upcoming Events -->
      <div class="col-lg-4">
        <div class="card-ems p-4 h-100">
          <h5 class="mb-4">Upcoming Events</h5>
          <div class="d-flex flex-column gap-3">
            <?php foreach($upcomingEvents as $ev): ?>
            <div class="p-3 rounded-ems" style="background:var(--bg-input);border:1px solid var(--border-glass)">
              <div class="fw-bold text-primary mb-1"><?= e($ev['title']) ?></div>
              <div class="d-flex justify-content-between text-muted" style="font-size:.8rem">
                <span><i class="bi bi-calendar me-1"></i><?= date('d M Y', strtotime($ev['date'])) ?></span>
                <span class="text-purple"><?= $ev['registered'] ?>/<?= $ev['capacity'] ?> booked</span>
              </div>
              <div class="progress mt-2" style="height:4px">
                <div class="progress-bar bg-purple" style="width:<?= ($ev['capacity']>0) ? ($ev['registered']/$ev['capacity']*100) : 0 ?>%"></div>
              </div>
            </div>
            <?php endforeach; ?>
            <?php if(empty($upcomingEvents)): ?>
              <div class="text-center text-muted py-4">No upcoming events.</div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
