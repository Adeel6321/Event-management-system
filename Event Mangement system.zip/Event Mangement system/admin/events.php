<?php
/**
 * EMS — Admin Event Management
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();

$pageTitle  = 'Manage Events';
$activePage = 'admin';

// Search
$search = $_GET['q'] ?? '';
$where = "1=1";
$params = [];
if ($search) {
    $where .= " AND (e.title LIKE ? OR u.name LIKE ?)";
    $term = "%$search%";
    $params = [$term, $term];
}

$stmt = $pdo->prepare("
    SELECT e.id, e.title, e.date, e.status, e.registered, e.capacity, e.type, 
           u.name AS organizer_name
    FROM events e
    LEFT JOIN users u ON e.organizer_id = u.id
    WHERE $where
    ORDER BY e.created_at DESC
");
$stmt->execute($params);
$events = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-wrapper">
  <!-- Sidebar -->
  <aside class="admin-sidebar" id="adminSidebar">
    <a href="<?= SITE_URL ?>/index.php" class="sidebar-logo">
      <div class="brand-icon" style="width:28px;height:28px;font-size:.9rem">🎫</div>
      <div class="sidebar-logo-text">EMS<span>·Admin</span></div>
    </a>
    
    <div class="sidebar-section">Overview</div>
    <a href="dashboard.php" class="sidebar-link"><i class="bi bi-speedometer2"></i> Dashboard</a>
    
    <div class="sidebar-section">Management</div>
    <a href="users.php" class="sidebar-link"><i class="bi bi-people"></i> Users</a>
    <a href="events.php" class="sidebar-link active"><i class="bi bi-calendar-event"></i> Events</a>
    <a href="venues.php" class="sidebar-link"><i class="bi bi-building"></i> Venues</a>
    <a href="bookings.php" class="sidebar-link"><i class="bi bi-ticket-perforated"></i> Bookings</a>
    
    <div class="sidebar-section">Data</div>
    <a href="reports.php" class="sidebar-link"><i class="bi bi-bar-chart"></i> Reports</a>
    
    <div class="sidebar-footer">
      <a href="<?= SITE_URL ?>/auth/logout.php" class="sidebar-link" style="color:var(--red)"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
  </aside>

  <!-- Content -->
  <main class="admin-content scroll-animate">
    <div class="admin-topbar">
      <div>
        <h1 class="page-title mb-0">Manage Events</h1>
        <div class="page-breadcrumb"><a href="dashboard.php">Admin</a> / Events</div>
      </div>
      <div class="d-flex gap-2">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="bi bi-list"></i></button>
        <a href="<?= SITE_URL ?>/events/create.php" class="btn-ems btn-primary-ems btn-sm-ems"><i class="bi bi-plus-lg"></i> Add Event</a>
      </div>
    </div>

    <div class="card-ems p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <form action="" method="GET" class="search-bar" style="max-width:300px;margin:0">
          <i class="bi bi-search text-muted px-2"></i>
          <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search events...">
        </form>
        <span class="badge badge-purple"><?= count($events) ?> Events</span>
      </div>

      <div class="table-responsive">
        <table class="table-ems" id="searchableTable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Event Title</th>
              <th>Organizer</th>
              <th>Date</th>
              <th>Booked / Cap</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($events as $e): ?>
            <tr>
              <td>#<?= $e['id'] ?></td>
              <td class="td-primary">
                <?= e(mb_strimwidth($e['title'], 0, 40, '...')) ?>
                <?php if($e['type']==='paid') echo '<span class="badge badge-warning ms-1" style="font-size:.65rem">Paid</span>'; ?>
              </td>
              <td><?= e($e['organizer_name']) ?></td>
              <td><?= formatDate($e['date']) ?></td>
              <td>
                <div class="d-flex align-items-center gap-2">
                  <span><?= $e['registered'] ?>/<?= $e['capacity'] ?></span>
                  <div class="progress" style="width:40px;height:4px">
                    <div class="progress-bar bg-purple" style="width:<?= $e['capacity']>0 ? ($e['registered']/$e['capacity']*100) : 0 ?>%"></div>
                  </div>
                </div>
              </td>
              <td><?= statusBadge($e['status']) ?></td>
              <td>
                <a href="<?= SITE_URL ?>/events/edit.php?id=<?= $e['id'] ?>" class="btn-ems btn-ghost-ems px-2 py-1" style="font-size:.75rem">
                  <i class="bi bi-pencil-square"></i> Edit
                </a>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($events)): ?>
            <tr><td colspan="7" class="text-center py-4 text-muted">No events found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
