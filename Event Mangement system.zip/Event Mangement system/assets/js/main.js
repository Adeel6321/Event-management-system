/**
 * EMS — Main JavaScript
 * Event Management System — IUB
 */

// ─── Theme Switcher Logic ─────────────────────────────────────────
window.setTheme = function(theme) {
  if (theme === 'default') {
    document.documentElement.removeAttribute('data-theme');
    localStorage.removeItem('ems-theme');
  } else {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('ems-theme', theme);
  }
};

document.addEventListener('DOMContentLoaded', () => {

  // ─── Stars Background Animation ──────────────────────────────────
  const bgMesh = document.querySelector('.bg-mesh');
  if (bgMesh) {
    const styleEl = document.createElement('style');
    let styleContent = `
      .star-layer { position: absolute; top: 0; left: 0; border-radius: 50%; opacity: 0.8; }
      .star-layer::after { content: " "; position: absolute; top: 2000px; width: inherit; height: inherit; background: transparent; }
      @keyframes animStar { from { transform: translateY(0); } to { transform: translateY(-2000px); } }
    `;
    
    const createStars = (count, size, duration, index) => {
      let shadows = [];
      for (let i = 0; i < count; i++) {
        const x = Math.floor(Math.random() * 2000);
        const y = Math.floor(Math.random() * 2000);
        const opacity = (Math.random() * 0.6 + 0.4).toFixed(2);
        shadows.push(`${x}px ${y}px rgba(255, 255, 255, ${opacity})`);
      }
      const shadowStr = shadows.join(', ');
      
      styleContent += `
        .stars-${index} { width: ${size}px; height: ${size}px; box-shadow: ${shadowStr}; animation: animStar ${duration}s linear infinite; }
        .stars-${index}::after { box-shadow: ${shadowStr}; }
      `;
      
      const layer = document.createElement('div');
      layer.className = `star-layer stars-${index}`;
      bgMesh.appendChild(layer);
    };

    // Parallax effect: diff sizes and diff speeds
    createStars(350, 1, 60, 1);
    createStars(150, 2, 120, 2);
    createStars(50, 3, 180, 3);
    
    styleEl.innerHTML = styleContent;
    document.head.appendChild(styleEl);
  }

  // ─── Bootstrap Tooltips & Popovers ─────────────────────────────
  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
  tooltipTriggerList.forEach(el => new bootstrap.Tooltip(el, { trigger: 'hover' }));

  const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]');
  popoverTriggerList.forEach(el => new bootstrap.Popover(el));

  // ─── Auto-dismiss alerts ────────────────────────────────────────
  document.querySelectorAll('.alert-custom').forEach(alert => {
    setTimeout(() => {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
      if (bsAlert) bsAlert.close();
    }, 5000);
  });

  // ─── Animated Stats Counter ─────────────────────────────────────
  const animateCounter = (el) => {
    const target = parseInt(el.dataset.target || el.textContent.replace(/\D/g, ''));
    const suffix = el.dataset.suffix || '';
    let start = 0;
    const duration = 1800;
    const step = Math.ceil(target / (duration / 16));
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        el.textContent = target.toLocaleString() + suffix;
        clearInterval(timer);
      } else {
        el.textContent = start.toLocaleString() + suffix;
      }
    }, 16);
  };

  // Trigger counter when visible
  const counters = document.querySelectorAll('[data-counter]');
  if (counters.length > 0) {
    const counterObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !entry.target.dataset.animated) {
          entry.target.dataset.animated = 'true';
          animateCounter(entry.target);
        }
      });
    }, { threshold: 0.3 });
    counters.forEach(el => counterObserver.observe(el));
  }

  // ─── Scroll Animations ──────────────────────────────────────────
  const scrollEls = document.querySelectorAll('.scroll-animate');
  if (scrollEls.length > 0) {
    const scrollObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry, i) => {
        if (entry.isIntersecting) {
          setTimeout(() => entry.target.classList.add('visible'), i * 80);
          scrollObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    scrollEls.forEach(el => scrollObserver.observe(el));
  }

  // ─── Notification Bell ──────────────────────────────────────────
  const notifBell = document.getElementById('notifBell');
  const notifDropdown = document.getElementById('notifDropdown');
  if (notifBell && notifDropdown) {
    notifBell.addEventListener('click', (e) => {
      e.stopPropagation();
      notifDropdown.classList.toggle('show');
      // Mark notifications read via AJAX
      if (notifDropdown.classList.contains('show')) {
        fetch('notifications/mark_read.php', { method: 'POST' }).catch(() => {});
        const badge = document.getElementById('notifBadge');
        if (badge) badge.style.display = 'none';
      }
    });
    document.addEventListener('click', () => notifDropdown.classList.remove('show'));
  }

  // ─── Admin Sidebar Toggle ───────────────────────────────────────
  const sidebarToggle = document.getElementById('sidebarToggle');
  const adminSidebar  = document.getElementById('adminSidebar');
  const sidebarOverlay = document.getElementById('sidebarOverlay');
  if (sidebarToggle && adminSidebar) {
    sidebarToggle.addEventListener('click', () => {
      adminSidebar.classList.toggle('open');
      if (sidebarOverlay) sidebarOverlay.classList.toggle('show');
    });
    if (sidebarOverlay) {
      sidebarOverlay.addEventListener('click', () => {
        adminSidebar.classList.remove('open');
        sidebarOverlay.classList.remove('show');
      });
    }
  }

  // ─── Live Search (debounced) ────────────────────────────────────
  const liveSearch = document.getElementById('liveSearch');
  if (liveSearch) {
    let searchTimer;
    liveSearch.addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        const form = liveSearch.closest('form');
        if (form) form.submit();
      }, 500);
    });
  }

  // ─── Ticket Quantity Input ──────────────────────────────────────
  const qtyInput = document.getElementById('qtyInput');
  const qtyMinus = document.getElementById('qtyMinus');
  const qtyPlus  = document.getElementById('qtyPlus');
  const totalPrice = document.getElementById('totalPrice');
  const pricePerTicket = parseFloat(document.getElementById('pricePerTicket')?.dataset.price || 0);

  if (qtyInput && qtyMinus && qtyPlus) {
    const maxSeats = parseInt(qtyInput.max) || 10;
    qtyMinus.addEventListener('click', () => {
      const val = parseInt(qtyInput.value);
      if (val > 1) { qtyInput.value = val - 1; updateTotal(); }
    });
    qtyPlus.addEventListener('click', () => {
      const val = parseInt(qtyInput.value);
      if (val < maxSeats) { qtyInput.value = val + 1; updateTotal(); }
    });
    qtyInput.addEventListener('change', updateTotal);
  }

  function updateTotal() {
    const qty = parseInt(qtyInput?.value || 1);
    if (totalPrice) {
      const price = pricePerTicket * qty;
      totalPrice.textContent = price > 0 ? 'PKR ' + price.toLocaleString() : 'Free';
    }
  }

  // ─── Image Preview on Upload ────────────────────────────────────
  const imgUpload = document.getElementById('imgUpload');
  const imgPreview = document.getElementById('imgPreview');
  if (imgUpload && imgPreview) {
    imgUpload.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (evt) => {
          imgPreview.src = evt.target.result;
          imgPreview.style.display = 'block';
        };
        reader.readAsDataURL(file);
      }
    });
  }

  // ─── Form Validation Feedback ───────────────────────────────────
  document.querySelectorAll('form.needs-validation').forEach(form => {
    form.addEventListener('submit', (e) => {
      if (!form.checkValidity()) {
        e.preventDefault();
        e.stopPropagation();
      }
      form.classList.add('was-validated');
    });
  });

  // ─── Delete Confirmation ────────────────────────────────────────
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', (e) => {
      const msg = el.dataset.confirm || 'Are you sure?';
      if (!confirm(msg)) e.preventDefault();
    });
  });

  // ─── Staggered Card Animations ──────────────────────────────────
  document.querySelectorAll('.card-ems').forEach((card, i) => {
    card.style.animationDelay = `${i * 0.06}s`;
    card.classList.add('animate-slide-up');
  });

  // ─── Dark theme table search ───────────────────────────────────
  const tableSearch = document.getElementById('tableSearch');
  const searchTable = document.getElementById('searchableTable');
  if (tableSearch && searchTable) {
    tableSearch.addEventListener('input', () => {
      const query = tableSearch.value.toLowerCase();
      searchTable.querySelectorAll('tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(query) ? '' : 'none';
      });
    });
  }

  // ─── Smooth Anchor Scroll ───────────────────────────────────────
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
      const target = document.querySelector(anchor.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // ─── Capacity Progress Bar Animation ───────────────────────────
  document.querySelectorAll('.progress-bar').forEach(bar => {
    const width = bar.style.width;
    bar.style.width = '0';
    setTimeout(() => { bar.style.width = width; }, 300);
  });

  // ─── Star Rating Interactive ────────────────────────────────────
  const starLabels = document.querySelectorAll('.star-rating-input label');
  starLabels.forEach((label, i) => {
    label.addEventListener('mouseover', () => {
      starLabels.forEach((l, j) => {
        l.style.color = j >= i ? 'var(--gold)' : 'var(--text-muted)';
      });
    });
    label.addEventListener('mouseout', () => {
      starLabels.forEach(l => l.style.color = '');
    });
  });

});
