<?php
/**
 * Event Management System (EMS)
 * Database Configuration & Session Initialization
 * Institution: IUB, Department of Information Technology
 * Developer: Muhammad Adeel Jameel
 */

// ─── Constants ───────────────────────────────────────────────────────────────
define('DB_HOST',    'localhost');
define('DB_NAME',    'ems_db');
define('DB_USER',    'root');
define('DB_PASS',    '');
define('DB_CHARSET', 'utf8mb4');

define('SITE_NAME',  'EMS — IUB');
define('SITE_URL',   'http://localhost/Event%20Mangement%20system');
define('SITE_ROOT',  dirname(__DIR__));

define('UPLOAD_DIR', SITE_ROOT . '/assets/uploads/');
define('UPLOAD_URL', SITE_URL  . '/assets/uploads/');

define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_MINUTES',   15);

// ─── Session ─────────────────────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_strict_mode', 1);
    session_start();
}

// ─── PDO Connection ──────────────────────────────────────────────────────────
try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET),
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // Show a friendly error page in production
    http_response_code(500);
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>Database Error — EMS</title>
    <style>
        body{margin:0;background:#0a0f1e;color:#f1f5f9;font-family:sans-serif;
             display:flex;align-items:center;justify-content:center;height:100vh}
        .box{text-align:center;padding:2rem;border:1px solid rgba(239,68,68,.3);
             border-radius:16px;background:rgba(239,68,68,.05)}
        h1{color:#ef4444;font-size:1.5rem}
        p{color:#94a3b8;font-size:.9rem}
        code{background:rgba(0,0,0,.3);padding:.2rem .6rem;border-radius:4px;
             font-size:.85rem;color:#fca5a5}
    </style></head><body>
    <div class="box">
        <h1>⚠ Database Connection Failed</h1>
        <p>Please make sure XAMPP MySQL service is running and the database <code>ems_db</code> exists.</p>
        <p>Run <code>database/ems_schema.sql</code> in phpMyAdmin, then run <code>setup.php</code>.</p>
    </div></body></html>';
    exit;
}
