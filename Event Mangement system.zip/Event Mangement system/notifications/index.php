<?php
/**
 * EMS — User Notifications
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireLogin();

$pageTitle = 'Notifications';

// Mark all as read if requested
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_all_read'])) {
    if (verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $pdo->prepare("UPDATE notifications SET status = 'read' WHERE user_id = ?")->execute([$_SESSION['user_id']]);
        redirect(SITE_URL . '/notifications/index.php');
    }
}

// Fetch notifications
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY sent_at DESC LIMIT 50");
$stmt->execute([$_SESSION['user_id']]);
$notifications = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-8 scroll-animate">
      
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="page-title mb-0">Notifications</h1>
        <?php if (!empty($notifications)): ?>
        <form method="POST" action="">
          <?= csrfField() ?>
          <input type="hidden" name="mark_all_read" value="1">
          <button type="submit" class="btn-ems btn-ghost-ems btn-sm-ems"><i class="bi bi-check2-all me-1"></i> Mark All Read</button>
        </form>
        <?php endif; ?>
      </div>

      <?php if (empty($notifications)): ?>
        <div class="empty-state">
          <i class="bi bi-bell-slash"></i>
          <h4>No notifications</h4>
          <p>You're all caught up!</p>
        </div>
      <?php else: ?>
        <div class="card-ems p-0 overflow-hidden">
          <ul class="list-group list-group-flush" style="background:transparent">
            <?php foreach ($notifications as $n): ?>
            <li class="list-group-item p-4" style="background:transparent;border-bottom:1px solid var(--border-glass);<?= $n['status'] === 'unread' ? 'background:rgba(124,58,237,.05)' : '' ?>">
              <div class="d-flex gap-3">
                <div class="stat-icon" style="width:40px;height:40px;font-size:1rem;background:var(--purple-light);color:#fff">
                  <?= match($n['type']) {
                      'booking' => '<i class="bi bi-ticket"></i>',
                      'system' => '<i class="bi bi-info-circle"></i>',
                      'cancellation' => '<i class="bi bi-x-circle"></i>',
                      default => '<i class="bi bi-bell"></i>'
                  } ?>
                </div>
                <div class="flex-grow-1">
                  <div class="d-flex justify-content-between align-items-start mb-1">
                    <h6 class="mb-0 text-primary <?= $n['status'] === 'unread' ? 'fw-bold' : '' ?>"><?= e($n['title']) ?></h6>
                    <small class="text-muted"><?= timeAgo($n['sent_at']) ?></small>
                  </div>
                  <p class="mb-2 text-secondary" style="font-size:.9rem"><?= e($n['message']) ?></p>
                  <?php if($n['link']): ?>
                    <a href="<?= SITE_URL . $n['link'] ?>" class="btn-ems btn-outline-ems py-1 px-2" style="font-size:.75rem">View Details</a>
                  <?php endif; ?>
                </div>
              </div>
            </li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

    </div>
  </div>
</div>

<?php 
// Mark shown notifications as read
if (!empty($notifications)) {
    $pdo->prepare("UPDATE notifications SET status = 'read' WHERE user_id = ? AND status = 'unread'")->execute([$_SESSION['user_id']]);
}
require_once __DIR__ . '/../includes/footer.php'; 
?>
