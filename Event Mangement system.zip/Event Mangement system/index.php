<?php
/**
 * EMS — Landing / Home Page
 * Showcases the system, features upcoming events, and drives registration.
 */
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle  = 'Home — Event Management System';
$activePage = 'home';

// Fetch featured published events (upcoming)
$featuredEvents = $pdo->query(
    "SELECT e.*, v.name AS venue_name, v.city
     FROM events e
     LEFT JOIN venues v ON e.venue_id = v.id
     WHERE e.status = 'published' AND e.date >= CURDATE()
     ORDER BY e.date ASC LIMIT 6"
)->fetchAll();

// Stats
$stats = [
    'events'  => (int)$pdo->query("SELECT COUNT(*) FROM events WHERE status='published'")->fetchColumn(),
    'users'   => (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
    'venues'  => (int)$pdo->query("SELECT COUNT(*) FROM venues WHERE availability=1")->fetchColumn(),
    'bookings'=> (int)$pdo->query("SELECT COUNT(*) FROM bookings WHERE status='confirmed'")->fetchColumn(),
];

require_once __DIR__ . '/includes/header.php';
?>

<!-- ─── HERO SECTION ──────────────────────────────────────────────── -->
<section class="hero-section" id="hero" aria-labelledby="hero-heading">
  <div class="container">
    <div class="row align-items-center g-5">

      <!-- Hero Content -->
      <div class="col-lg-6">
        <div class="hero-badge">
          <i class="bi bi-mortarboard-fill"></i>
          IUB — Department of Information Technology
        </div>

        <h1 class="hero-title" id="hero-heading">
          Manage Events<br>
          <span class="highlight">Smarter & Faster</span>
        </h1>

        <p class="hero-desc">
          Discover, book, and manage events at The Islamia University of Bahawalpur.
          One platform for organizers, attendees, and administrators — all in one place.
        </p>

        <div class="hero-actions">
          <a href="<?= SITE_URL ?>/events/index.php" class="btn-ems btn-primary-ems btn-lg-ems">
            <i class="bi bi-calendar-event-fill"></i>
            Explore Events
          </a>
          <?php if (!isLoggedIn()): ?>
          <a href="<?= SITE_URL ?>/auth/register.php" class="btn-ems btn-outline-ems btn-lg-ems">
            <i class="bi bi-person-plus-fill"></i>
            Register Free
          </a>
          <?php else: ?>
          <a href="<?= SITE_URL ?>/bookings/my_bookings.php" class="btn-ems btn-outline-ems btn-lg-ems">
            <i class="bi bi-ticket-perforated-fill"></i>
            My Bookings
          </a>
          <?php endif; ?>
        </div>

        <!-- Stats Row -->
        <div class="hero-stats">
          <div>
            <div class="hero-stat-num">
              <span data-counter data-target="<?= $stats['events'] ?>" data-suffix="+"><?= $stats['events'] ?>+</span>
            </div>
            <div class="hero-stat-label">Live Events</div>
          </div>
          <div>
            <div class="hero-stat-num">
              <span data-counter data-target="<?= $stats['users'] ?>" data-suffix="+"><?= $stats['users'] ?>+</span>
            </div>
            <div class="hero-stat-label">Registered Users</div>
          </div>
          <div>
            <div class="hero-stat-num">
              <span data-counter data-target="<?= $stats['venues'] ?>"><?= $stats['venues'] ?></span>
            </div>
            <div class="hero-stat-label">Venues</div>
          </div>
          <div>
            <div class="hero-stat-num">
              <span data-counter data-target="<?= $stats['bookings'] ?>" data-suffix="+"><?= $stats['bookings'] ?>+</span>
            </div>
            <div class="hero-stat-label">Bookings</div>
          </div>
        </div>
      </div>

      <!-- Hero Visual -->
      <div class="col-lg-6 d-none d-lg-block">
        <div class="hero-visual" style="height:500px">
          <!-- Floating Cards -->
          <div class="hero-visual-card card-1">
            <div class="d-flex align-items-center gap-2 mb-2">
              <div style="width:32px;height:32px;background:linear-gradient(135deg,#7c3aed,#4f46e5);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.9rem">🎓</div>
              <div>
                <div style="font-weight:700;font-size:.88rem">IT Conference 2026</div>
                <div style="font-size:.75rem;color:var(--text-muted)">Conference</div>
              </div>
            </div>
            <div style="font-size:.8rem;color:var(--text-secondary);margin-bottom:.75rem">
              <i class="bi bi-calendar3 me-1"></i> <?= date('d M Y', strtotime('+7 days')) ?>
            </div>
            <div style="font-size:.75rem;color:var(--text-muted);margin-bottom:4px">Registration</div>
            <div class="progress" style="height:5px">
              <div class="progress-bar bg-success" style="width:40%"></div>
            </div>
            <div style="font-size:.72rem;color:var(--text-muted);margin-top:3px">320 / 800 seats</div>
          </div>

          <div class="hero-visual-card card-2">
            <div class="d-flex align-items-center gap-2 mb-2">
              <div style="width:32px;height:32px;background:linear-gradient(135deg,#f59e0b,#d97706);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.9rem">🎵</div>
              <div>
                <div style="font-weight:700;font-size:.88rem">Cultural Night</div>
                <div style="font-size:.75rem;color:var(--text-muted)">Cultural Event</div>
              </div>
            </div>
            <div style="background:rgba(245,158,11,.1);border-radius:8px;padding:8px;font-size:.8rem">
              <span style="color:var(--gold);font-weight:700">PKR 300</span>
              <span style="color:var(--text-muted)"> / ticket</span>
            </div>
            <div style="margin-top:.6rem">
              <span class="badge badge-warning">250 booked</span>
            </div>
          </div>

          <div class="hero-visual-card card-3">
            <div style="font-size:.75rem;color:var(--text-muted);margin-bottom:6px">🔔 Booking Confirmed!</div>
            <div style="font-weight:700;font-size:.9rem;margin-bottom:4px">Laravel Workshop</div>
            <div style="font-size:.78rem;color:var(--green)"><i class="bi bi-check-circle-fill me-1"></i> Your seat is reserved</div>
            <div style="font-size:.75rem;color:var(--text-muted);margin-top:4px">Ref: EMS-A3F7B2C1</div>
          </div>

          <!-- Background glow circles -->
          <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
                       width:300px;height:300px;
                       background:radial-gradient(circle,rgba(124,58,237,.15),transparent);
                       border-radius:50%;pointer-events:none"></div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ─── FEATURED EVENTS ────────────────────────────────────────────── -->
<section class="py-5" id="featured-events" aria-labelledby="events-heading">
  <div class="container">

    <div class="section-header scroll-animate">
      <div class="section-label"><i class="bi bi-stars me-1"></i> Upcoming</div>
      <h2 class="section-title" id="events-heading">Featured Events</h2>
      <p class="section-desc">Don't miss out — explore and book upcoming events at IUB and beyond.</p>
    </div>

    <!-- Category Filter Pills -->
    <div class="filter-pills justify-content-center mb-4 scroll-animate">
      <a href="<?= SITE_URL ?>/events/index.php" class="filter-pill active">All Events</a>
      <a href="<?= SITE_URL ?>/events/index.php?category=conference" class="filter-pill">
        <i class="bi bi-people-fill"></i> Conference
      </a>
      <a href="<?= SITE_URL ?>/events/index.php?category=seminar" class="filter-pill">
        <i class="bi bi-mortarboard-fill"></i> Seminar
      </a>
      <a href="<?= SITE_URL ?>/events/index.php?category=sports" class="filter-pill">
        <i class="bi bi-trophy-fill"></i> Sports
      </a>
      <a href="<?= SITE_URL ?>/events/index.php?category=cultural" class="filter-pill">
        <i class="bi bi-palette-fill"></i> Cultural
      </a>
      <a href="<?= SITE_URL ?>/events/index.php?category=music" class="filter-pill">
        <i class="bi bi-music-note-beamed"></i> Music
      </a>
    </div>

    <?php if (empty($featuredEvents)): ?>
      <div class="empty-state scroll-animate">
        <i class="bi bi-calendar-x"></i>
        <h4>No upcoming events yet</h4>
        <p>Check back soon or run setup.php to add sample events.</p>
      </div>
    <?php else: ?>
    <div class="row g-4">
      <?php foreach ($featuredEvents as $ev): ?>
      <div class="col-xl-4 col-md-6 scroll-animate">
        <div class="card-ems h-100">
          <!-- Event Banner -->
          <div class="card-event-banner" style="background:linear-gradient(135deg,<?= categoryColor($ev['category']) ?>22,<?= categoryColor($ev['category']) ?>08)">
            <div style="font-size:3.5rem; opacity:.8">
              <?= match($ev['category']) {
                'conference' => '🎤', 'wedding' => '💍', 'music' => '🎵',
                'sports'     => '🏆', 'cultural' => '🎭', 'corporate' => '💼',
                'seminar'    => '🎓', default    => '📅',
              } ?>
            </div>
            <!-- Status badge -->
            <div style="position:absolute;top:12px;right:12px">
              <?= $ev['type'] === 'paid'
                ? "<span class='badge badge-warning'>PKR " . number_format($ev['ticket_price']) . "</span>"
                : "<span class='badge badge-success'>Free</span>" ?>
            </div>
          </div>

          <div class="card-body-ems">
            <!-- Category -->
            <div class="event-category-badge"
                 style="background:<?= categoryColor($ev['category']) ?>20;color:<?= categoryColor($ev['category']) ?>">
              <i class="bi <?= categoryIcon($ev['category']) ?>"></i>
              <?= ucfirst($ev['category']) ?>
            </div>

            <!-- Title -->
            <h3 class="card-title-ems"><?= e($ev['title']) ?></h3>

            <!-- Meta -->
            <div class="card-meta">
              <span><i class="bi bi-calendar3 text-purple"></i> <?= formatDate($ev['date']) ?> &bull; <?= formatTime($ev['time']) ?></span>
              <?php if ($ev['venue_name']): ?>
              <span><i class="bi bi-geo-alt text-purple"></i> <?= e($ev['venue_name']) ?><?= $ev['city'] ? ', '.$ev['city'] : '' ?></span>
              <?php endif; ?>
            </div>

            <!-- Capacity -->
            <?= capacityBar($ev['registered'], $ev['capacity']) ?>

            <!-- Action -->
            <div class="d-flex gap-2 mt-3">
              <a href="<?= SITE_URL ?>/events/detail.php?id=<?= $ev['id'] ?>"
                 class="btn-ems btn-primary-ems btn-sm-ems flex-grow-1 justify-content-center">
                <i class="bi bi-arrow-right-circle"></i> View Details
              </a>
              <?php $seatsLeft = $ev['capacity'] - $ev['registered']; ?>
              <?php if ($seatsLeft > 0): ?>
              <a href="<?= SITE_URL ?>/bookings/book.php?event_id=<?= $ev['id'] ?>"
                 class="btn-ems btn-gold-ems btn-sm-ems">
                <i class="bi bi-ticket-perforated"></i> Book
              </a>
              <?php else: ?>
              <span class="btn-ems btn-danger-ems btn-sm-ems" style="opacity:.6;cursor:default">Full</span>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="text-center mt-5 scroll-animate">
      <a href="<?= SITE_URL ?>/events/index.php" class="btn-ems btn-outline-ems btn-lg-ems">
        <i class="bi bi-grid-3x3-gap-fill"></i> Browse All Events
      </a>
    </div>
    <?php endif; ?>

  </div>
</section>

<hr class="section-divider">

<!-- ─── HOW IT WORKS ──────────────────────────────────────────────── -->
<section class="py-5" id="how-it-works" aria-labelledby="how-heading">
  <div class="container">

    <div class="section-header scroll-animate">
      <div class="section-label">Simple & Fast</div>
      <h2 class="section-title" id="how-heading">How It Works</h2>
      <p class="section-desc">From discovery to booking — get your event seat in 3 simple steps.</p>
    </div>

    <div class="row g-4">
      <?php
      $steps = [
        ['icon'=>'🔍','color'=>'rgba(59,130,246,.15)','colorText'=>'#3b82f6','step'=>'01','title'=>'Discover Events','desc'=>'Browse upcoming events by category, date, or location. Find exactly what interests you.'],
        ['icon'=>'🎫','color'=>'rgba(124,58,237,.15)','colorText'=>'#7c3aed','step'=>'02','title'=>'Book Your Seat','desc'=>'Select your event, choose your tickets, and confirm instantly. No queues, no hassle.'],
        ['icon'=>'🎉','color'=>'rgba(245,158,11,.15)','colorText'=>'#f59e0b','step'=>'03','title'=>'Enjoy the Event','desc'=>'Get a booking confirmation with your reference number and show up ready to enjoy!'],
      ];
      foreach ($steps as $s): ?>
      <div class="col-lg-4 col-md-6 scroll-animate">
        <div class="glass feature-card h-100">
          <div class="feature-icon mx-auto" style="background:<?= $s['color'] ?>;font-size:2rem">
            <?= $s['icon'] ?>
          </div>
          <div class="section-label mb-2" style="font-size:.7rem">Step <?= $s['step'] ?></div>
          <h4><?= $s['title'] ?></h4>
          <p><?= $s['desc'] ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

  </div>
</section>

<hr class="section-divider">

<!-- ─── STATS SECTION ─────────────────────────────────────────────── -->
<section class="py-5" aria-label="Platform statistics">
  <div class="container">
    <div class="glass-strong p-5" style="border-radius:var(--r-2xl);position:relative;overflow:hidden">
      <div style="position:absolute;inset:0;background:linear-gradient(135deg,rgba(124,58,237,.08),rgba(245,158,11,.04));pointer-events:none"></div>

      <div class="section-header scroll-animate" style="margin-bottom:2.5rem">
        <div class="section-label">By the Numbers</div>
        <h2 class="section-title">EMS at a Glance</h2>
      </div>

      <div class="row g-4">
        <?php
        $statItems = [
          ['num'=>$stats['events'],  'suf'=>'+','label'=>'Active Events',      'icon'=>'bi-calendar-check-fill','color'=>'purple'],
          ['num'=>$stats['users'],   'suf'=>'+','label'=>'Registered Users',   'icon'=>'bi-people-fill',        'color'=>'gold'],
          ['num'=>$stats['venues'],  'suf'=>'', 'label'=>'Partner Venues',     'icon'=>'bi-building',           'color'=>'green'],
          ['num'=>$stats['bookings'],'suf'=>'+','label'=>'Confirmed Bookings', 'icon'=>'bi-ticket-perforated-fill','color'=>'blue'],
        ];
        foreach ($statItems as $si): ?>
        <div class="col-lg-3 col-6 scroll-animate">
          <div class="stat-card <?= $si['color'] ?>">
            <div class="stat-icon <?= $si['color'] ?>">
              <i class="bi <?= $si['icon'] ?>"></i>
            </div>
            <div>
              <div class="stat-number"
                   data-counter
                   data-target="<?= $si['num'] ?>"
                   data-suffix="<?= $si['suf'] ?>">
                <?= number_format($si['num']) ?><?= $si['suf'] ?>
              </div>
              <div class="stat-label"><?= $si['label'] ?></div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ─── CTA SECTION ───────────────────────────────────────────────── -->
<section class="py-5" aria-label="Call to action">
  <div class="container">
    <div class="text-center scroll-animate" style="max-width:600px;margin:0 auto">
      <div class="section-label mb-3">Join Today</div>
      <h2 class="section-title" style="font-size:2.5rem">
        Ready to get started?
      </h2>
      <p class="section-desc mb-4">
        Create your free account and start discovering amazing events at IUB today.
        Organizers can list and manage events with ease.
      </p>
      <?php if (!isLoggedIn()): ?>
      <div class="d-flex gap-3 justify-content-center flex-wrap">
        <a href="<?= SITE_URL ?>/auth/register.php" class="btn-ems btn-primary-ems btn-lg-ems animate-glow">
          <i class="bi bi-rocket-takeoff-fill"></i> Get Started Free
        </a>
        <a href="<?= SITE_URL ?>/events/index.php" class="btn-ems btn-ghost-ems btn-lg-ems">
          <i class="bi bi-compass-fill"></i> Explore Events
        </a>
      </div>
      <?php else: ?>
      <div class="d-flex gap-3 justify-content-center flex-wrap">
        <a href="<?= SITE_URL ?>/events/index.php" class="btn-ems btn-primary-ems btn-lg-ems">
          <i class="bi bi-calendar-event-fill"></i> Browse Events
        </a>
        <?php if (isOrganizer()): ?>
        <a href="<?= SITE_URL ?>/events/create.php" class="btn-ems btn-gold-ems btn-lg-ems">
          <i class="bi bi-plus-circle-fill"></i> Create Event
        </a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
