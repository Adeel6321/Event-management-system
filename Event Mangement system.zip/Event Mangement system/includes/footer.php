<?php
/**
 * EMS — Global Footer
 * Variables expected:
 *   $extraScripts (string) — additional <script> tags before closing body
 */
if (!isset($extraScripts)) $extraScripts = '';
?>

<!-- ─── FOOTER ─────────────────────────────────────────────────────── -->
<footer class="ems-footer" role="contentinfo">
  <div class="container">
    <div class="row g-5">

      <!-- Brand Column -->
      <div class="col-lg-4 col-md-6">
        <div class="footer-logo">🎫 EMS<span>·IUB</span></div>
        <p class="footer-desc mt-2">
          Event Management System for The Islamia University of Bahawalpur,
          Department of Information Technology. Discover, book and manage events seamlessly.
        </p>
        <div class="social-links">
          <a href="#" class="social-link" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
          <a href="#" class="social-link" aria-label="Twitter"><i class="bi bi-twitter-x"></i></a>
          <a href="#" class="social-link" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
          <a href="#" class="social-link" aria-label="LinkedIn"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>

      <!-- Quick Links -->
      <div class="col-lg-2 col-md-3 col-6">
        <div class="footer-heading">Quick Links</div>
        <ul class="footer-links">
          <li><a href="<?= SITE_URL ?>/index.php"><i class="bi bi-chevron-right me-1"></i>Home</a></li>
          <li><a href="<?= SITE_URL ?>/events/index.php"><i class="bi bi-chevron-right me-1"></i>Events</a></li>
          <li><a href="<?= SITE_URL ?>/venues/index.php"><i class="bi bi-chevron-right me-1"></i>Venues</a></li>
          <li><a href="<?= SITE_URL ?>/auth/register.php"><i class="bi bi-chevron-right me-1"></i>Register</a></li>
          <li><a href="<?= SITE_URL ?>/auth/login.php"><i class="bi bi-chevron-right me-1"></i>Login</a></li>
        </ul>
      </div>

      <!-- Event Categories -->
      <div class="col-lg-2 col-md-3 col-6">
        <div class="footer-heading">Categories</div>
        <ul class="footer-links">
          <li><a href="<?= SITE_URL ?>/events/index.php?category=conference"><i class="bi bi-chevron-right me-1"></i>Conference</a></li>
          <li><a href="<?= SITE_URL ?>/events/index.php?category=seminar"><i class="bi bi-chevron-right me-1"></i>Seminar</a></li>
          <li><a href="<?= SITE_URL ?>/events/index.php?category=cultural"><i class="bi bi-chevron-right me-1"></i>Cultural</a></li>
          <li><a href="<?= SITE_URL ?>/events/index.php?category=sports"><i class="bi bi-chevron-right me-1"></i>Sports</a></li>
          <li><a href="<?= SITE_URL ?>/events/index.php?category=music"><i class="bi bi-chevron-right me-1"></i>Music</a></li>
        </ul>
      </div>

      <!-- Contact Info -->
      <div class="col-lg-4 col-md-6">
        <div class="footer-heading">Contact</div>
        <ul class="footer-links">
          <li style="color:var(--text-secondary);font-size:.88rem;display:flex;gap:8px;align-items:flex-start;margin-bottom:.75rem">
            <i class="bi bi-geo-alt-fill" style="color:var(--purple-light);margin-top:2px;flex-shrink:0"></i>
            Department of Information Technology,<br>
            The Islamia University of Bahawalpur,<br>Bahawalpur, Pakistan
          </li>
          <li style="color:var(--text-secondary);font-size:.88rem;display:flex;gap:8px;align-items:center;margin-bottom:.5rem">
            <i class="bi bi-envelope-fill" style="color:var(--purple-light)"></i>
            it@iub.edu.pk
          </li>
          <li style="color:var(--text-secondary);font-size:.88rem;display:flex;gap:8px;align-items:center">
            <i class="bi bi-telephone-fill" style="color:var(--purple-light)"></i>
            +92-62-9255037
          </li>
        </ul>
      </div>

    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom d-flex flex-column flex-sm-row align-items-center justify-content-between gap-2">
      <div>
        &copy; <?= date('Y') ?> <strong>EMS — IUB</strong>. All rights reserved.
        &nbsp;|&nbsp; Developed by <strong>Muhammad Adeel Jameel</strong>
        &nbsp;|&nbsp; Supervised by <strong>Ms. Sara Fareed</strong>
      </div>
      <div class="d-flex gap-3">
        <a href="#" style="color:var(--text-muted);font-size:.82rem">Privacy Policy</a>
        <a href="#" style="color:var(--text-muted);font-size:.82rem">Terms of Use</a>
      </div>
    </div>
  </div>
</footer>

<!-- ─── SCRIPTS ──────────────────────────────────────────────────── -->
<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js (for admin dashboards) -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<!-- EMS Custom JS -->
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>

<?= $extraScripts ?>

<!-- Sidebar overlay for mobile admin -->
<div id="sidebarOverlay"
     style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:199;backdrop-filter:blur(2px)">
</div>

<style>
#sidebarOverlay.show { display: block !important; }
.dropdown-menu { min-width: unset; }
</style>

</body>
</html>
