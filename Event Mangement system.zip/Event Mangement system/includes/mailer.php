<?php
/**
 * EMS — Email Notification Helper
 * Uses PHP's built-in mail() function.
 * For production, replace with PHPMailer + SMTP (Mailtrap / Gmail).
 */

/**
 * Send a notification email.
 *
 * @param string $to      Recipient email address
 * @param string $name    Recipient name
 * @param string $subject Email subject
 * @param string $body    HTML email body
 */
function sendEmail(string $to, string $name, string $subject, string $body): bool {
    $from    = 'noreply@ems-iub.edu.pk';
    $fromName = 'EMS — IUB';
    $headers = implode("\r\n", [
        'MIME-Version: 1.0',
        'Content-type: text/html; charset=UTF-8',
        "From: {$fromName} <{$from}>",
        "Reply-To: {$from}",
        'X-Mailer: PHP/' . phpversion(),
    ]);

    $html = buildEmailTemplate($name, $subject, $body);

    // In a real deployment, use PHPMailer/SMTP:
    // return (new PHPMailer\PHPMailer\PHPMailer())->...
    return @mail($to, $subject, $html, $headers);
}

/**
 * Build a branded HTML email template.
 */
function buildEmailTemplate(string $name, string $subject, string $body): string {
    return "<!DOCTYPE html>
<html>
<head>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>{$subject}</title>
<style>
  body{margin:0;padding:0;background:#0a0f1e;font-family:Arial,sans-serif}
  .wrapper{max-width:600px;margin:40px auto;background:#0f1729;border-radius:16px;
            overflow:hidden;border:1px solid rgba(124,58,237,.3)}
  .header{background:linear-gradient(135deg,#7c3aed,#4f46e5);padding:32px;text-align:center}
  .header h1{margin:0;color:#fff;font-size:24px;letter-spacing:1px}
  .header p{margin:4px 0 0;color:rgba(255,255,255,.8);font-size:13px}
  .body{padding:32px;color:#e2e8f0;line-height:1.7;font-size:15px}
  .body h2{color:#a78bfa;margin-top:0}
  .btn{display:inline-block;margin-top:20px;padding:12px 28px;
        background:linear-gradient(135deg,#7c3aed,#5b21b6);color:#fff;
        text-decoration:none;border-radius:8px;font-weight:600}
  .footer{text-align:center;padding:20px;color:#64748b;font-size:12px;
           border-top:1px solid rgba(255,255,255,.05)}
</style>
</head>
<body>
<div class='wrapper'>
  <div class='header'>
    <h1>🎫 EMS</h1>
    <p>Event Management System — IUB</p>
  </div>
  <div class='body'>
    <h2>Hello, {$name}!</h2>
    {$body}
  </div>
  <div class='footer'>
    &copy; " . date('Y') . " Event Management System — IUB, Department of Information Technology<br>
    This is an automated email, please do not reply.
  </div>
</div>
</body>
</html>";
}

/**
 * Pre-built email templates
 */

function sendBookingConfirmationEmail(string $to, string $name, array $booking, array $event): bool {
    $body = "
        <p>Your booking has been <strong style='color:#10b981'>confirmed</strong>!</p>
        <table style='width:100%;border-collapse:collapse;margin-top:16px'>
            <tr><td style='padding:8px;color:#94a3b8'>Event</td>
                <td style='padding:8px;color:#f1f5f9;font-weight:600'>{$event['title']}</td></tr>
            <tr style='background:rgba(255,255,255,.03)'>
                <td style='padding:8px;color:#94a3b8'>Date</td>
                <td style='padding:8px;color:#f1f5f9'>" . date('d M Y', strtotime($event['date'])) . " at " . date('h:i A', strtotime($event['time'])) . "</td></tr>
            <tr><td style='padding:8px;color:#94a3b8'>Tickets</td>
                <td style='padding:8px;color:#f1f5f9'>{$booking['quantity']}</td></tr>
            <tr style='background:rgba(255,255,255,.03)'>
                <td style='padding:8px;color:#94a3b8'>Total</td>
                <td style='padding:8px;color:#f59e0b;font-weight:700'>PKR {$booking['total_price']}</td></tr>
            <tr><td style='padding:8px;color:#94a3b8'>Reference</td>
                <td style='padding:8px;color:#a78bfa;font-weight:700'>{$booking['booking_reference']}</td></tr>
        </table>
        <p style='margin-top:20px;color:#94a3b8;font-size:13px'>
            Please keep your booking reference for check-in. We look forward to seeing you at the event!
        </p>";
    return sendEmail($to, $name, 'Booking Confirmed — ' . $event['title'], $body);
}

function sendCancellationEmail(string $to, string $name, array $event): bool {
    $body = "
        <p>Your booking for <strong style='color:#f59e0b'>{$event['title']}</strong> has been <strong style='color:#ef4444'>cancelled</strong>.</p>
        <p>If you did not request this cancellation, please contact us immediately.</p>
        <p style='color:#94a3b8;font-size:13px'>We hope to see you at future events!</p>";
    return sendEmail($to, $name, 'Booking Cancelled — ' . $event['title'], $body);
}

function sendVerificationEmail(string $to, string $name, string $token): bool {
    $link = SITE_URL . '/auth/verify_email.php?token=' . urlencode($token);
    $body = "
        <p>Thank you for registering with <strong>EMS — IUB</strong>!</p>
        <p>Please verify your email address by clicking the button below:</p>
        <a href='{$link}' class='btn'>✓ Verify Email Address</a>
        <p style='margin-top:20px;color:#94a3b8;font-size:12px'>
            Link expires in 24 hours. If you did not register, ignore this email.
        </p>";
    return sendEmail($to, $name, 'Verify Your Email — EMS IUB', $body);
}
