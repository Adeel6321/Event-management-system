<?php
/**
 * EMS — Utility / Helper Functions
 * All shared helper functions used across the application
 */

// ─── Output / Sanitization ───────────────────────────────────────────────────

/** Sanitize output for HTML display */
function e(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

/** Sanitize input (trim + strip tags) */
function sanitize(string $input): string {
    return trim(strip_tags($input));
}

// ─── Redirect ────────────────────────────────────────────────────────────────

function redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}

// ─── Flash Messages ──────────────────────────────────────────────────────────

function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function renderFlash(): string {
    $flash = getFlash();
    if (!$flash) return '';
    $icons = [
        'success' => 'bi-check-circle-fill',
        'danger'  => 'bi-exclamation-triangle-fill',
        'warning' => 'bi-exclamation-circle-fill',
        'info'    => 'bi-info-circle-fill',
    ];
    $icon = $icons[$flash['type']] ?? 'bi-info-circle-fill';
    return sprintf(
        '<div class="alert alert-custom alert-%s alert-dismissible fade show" role="alert">
            <i class="bi %s me-2"></i>%s
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>',
        e($flash['type']),
        $icon,
        e($flash['message'])
    );
}

// ─── Authentication Helpers ──────────────────────────────────────────────────

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function currentUser(): ?array {
    if (!isLoggedIn()) return null;
    return [
        'id'    => $_SESSION['user_id'],
        'name'  => $_SESSION['user_name']  ?? '',
        'email' => $_SESSION['user_email'] ?? '',
        'role'  => $_SESSION['user_role']  ?? 'attendee',
    ];
}

function hasRole(string ...$roles): bool {
    if (!isLoggedIn()) return false;
    return in_array($_SESSION['user_role'] ?? '', $roles, true);
}

function isAdmin(): bool     { return hasRole('admin'); }
function isOrganizer(): bool { return hasRole('organizer', 'admin'); }

// ─── Brute-Force Login Protection ────────────────────────────────────────────

function checkLoginLockout(PDO $pdo, string $email): bool {
    $stmt = $pdo->prepare('SELECT attempts, locked_until FROM login_attempts WHERE email = ?');
    $stmt->execute([$email]);
    $row = $stmt->fetch();
    if (!$row) return false;
    if ($row['locked_until'] && strtotime($row['locked_until']) > time()) {
        return true; // still locked
    }
    return false;
}

function getRemainingLockout(PDO $pdo, string $email): int {
    $stmt = $pdo->prepare('SELECT locked_until FROM login_attempts WHERE email = ?');
    $stmt->execute([$email]);
    $row = $stmt->fetch();
    if ($row && $row['locked_until']) {
        $remaining = strtotime($row['locked_until']) - time();
        return max(0, (int)ceil($remaining / 60));
    }
    return 0;
}

function recordFailedLogin(PDO $pdo, string $email, string $ip = ''): void {
    $stmt = $pdo->prepare('SELECT id, attempts FROM login_attempts WHERE email = ?');
    $stmt->execute([$email]);
    $row = $stmt->fetch();
    if ($row) {
        $attempts = $row['attempts'] + 1;
        $locked   = null;
        if ($attempts >= MAX_LOGIN_ATTEMPTS) {
            $locked = date('Y-m-d H:i:s', time() + LOCKOUT_MINUTES * 60);
        }
        $pdo->prepare('UPDATE login_attempts SET attempts=?, locked_until=?, ip_address=? WHERE email=?')
            ->execute([$attempts, $locked, $ip, $email]);
    } else {
        $pdo->prepare('INSERT INTO login_attempts (email, ip_address, attempts) VALUES (?,?,1)')
            ->execute([$email, $ip]);
    }
}

function clearLoginAttempts(PDO $pdo, string $email): void {
    $pdo->prepare('DELETE FROM login_attempts WHERE email = ?')->execute([$email]);
}

// ─── CSRF Protection ─────────────────────────────────────────────────────────

function generateCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function csrfField(): string {
    return '<input type="hidden" name="csrf_token" value="' . generateCsrfToken() . '">';
}

// ─── Notifications ───────────────────────────────────────────────────────────

function createNotification(PDO $pdo, int $userId, string $title, string $message, string $type = 'system', string $link = ''): void {
    $pdo->prepare('INSERT INTO notifications (user_id, title, message, type, link) VALUES (?,?,?,?,?)')
        ->execute([$userId, $title, $message, $type, $link]);
}

function getUnreadCount(PDO $pdo, int $userId): int {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND status = 'unread'");
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
}

// ─── Booking Reference Generator ─────────────────────────────────────────────

function generateBookingRef(): string {
    return 'EMS-' . strtoupper(bin2hex(random_bytes(4)));
}

// ─── Date & Time Formatting ──────────────────────────────────────────────────

function formatDate(string $date): string {
    return date('d M Y', strtotime($date));
}

function formatTime(string $time): string {
    return date('h:i A', strtotime($time));
}

function formatDateTime(string $datetime): string {
    return date('d M Y, h:i A', strtotime($datetime));
}

function timeAgo(string $datetime): string {
    $diff = time() - strtotime($datetime);
    if ($diff < 60)         return 'just now';
    if ($diff < 3600)       return floor($diff/60) . ' min ago';
    if ($diff < 86400)      return floor($diff/3600) . ' hr ago';
    if ($diff < 604800)     return floor($diff/86400) . ' days ago';
    return formatDate($datetime);
}

// ─── Pagination ──────────────────────────────────────────────────────────────

function paginate(int $total, int $perPage, int $current, string $urlPattern): string {
    $pages = (int)ceil($total / $perPage);
    if ($pages <= 1) return '';
    $html = '<nav aria-label="Pagination"><ul class="pagination justify-content-center">';
    $html .= sprintf(
        '<li class="page-item %s"><a class="page-link" href="%s">‹ Prev</a></li>',
        $current <= 1 ? 'disabled' : '',
        str_replace('{page}', max(1, $current - 1), $urlPattern)
    );
    for ($i = 1; $i <= $pages; $i++) {
        $html .= sprintf(
            '<li class="page-item %s"><a class="page-link" href="%s">%d</a></li>',
            $i === $current ? 'active' : '',
            str_replace('{page}', $i, $urlPattern),
            $i
        );
    }
    $html .= sprintf(
        '<li class="page-item %s"><a class="page-link" href="%s">Next ›</a></li>',
        $current >= $pages ? 'disabled' : '',
        str_replace('{page}', min($pages, $current + 1), $urlPattern)
    );
    $html .= '</ul></nav>';
    return $html;
}

// ─── Category Helpers ────────────────────────────────────────────────────────

function categoryIcon(string $cat): string {
    $icons = [
        'conference' => 'bi-people-fill',
        'wedding'    => 'bi-heart-fill',
        'music'      => 'bi-music-note-beamed',
        'sports'     => 'bi-trophy-fill',
        'cultural'   => 'bi-palette-fill',
        'corporate'  => 'bi-briefcase-fill',
        'seminar'    => 'bi-mortarboard-fill',
        'other'      => 'bi-calendar-event-fill',
    ];
    return $icons[$cat] ?? 'bi-calendar-event-fill';
}

function categoryColor(string $cat): string {
    $colors = [
        'conference' => '#3b82f6',
        'wedding'    => '#ec4899',
        'music'      => '#8b5cf6',
        'sports'     => '#f59e0b',
        'cultural'   => '#10b981',
        'corporate'  => '#6366f1',
        'seminar'    => '#06b6d4',
        'other'      => '#94a3b8',
    ];
    return $colors[$cat] ?? '#94a3b8';
}

function statusBadge(string $status): string {
    $map = [
        'published'  => ['success',  'Published'],
        'draft'      => ['secondary','Draft'],
        'cancelled'  => ['danger',   'Cancelled'],
        'completed'  => ['info',     'Completed'],
        'confirmed'  => ['success',  'Confirmed'],
        'pending'    => ['warning',  'Pending'],
        'active'     => ['success',  'Active'],
        'inactive'   => ['secondary','Inactive'],
    ];
    [$cls, $label] = $map[$status] ?? ['secondary', ucfirst($status)];
    return "<span class=\"badge badge-{$cls}\">{$label}</span>";
}

// ─── File Upload ─────────────────────────────────────────────────────────────

function uploadImage(array $file, string $subdir = 'events'): ?string {
    if ($file['error'] !== UPLOAD_ERR_OK) return null;
    $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!in_array($file['type'], $allowed)) return null;
    if ($file['size'] > 5 * 1024 * 1024) return null; // 5MB max

    $dir = UPLOAD_DIR . $subdir . '/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $ext      = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = $subdir . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest     = $dir . $filename;

    if (move_uploaded_file($file['tmp_name'], $dest)) {
        return $subdir . '/' . $filename;
    }
    return null;
}

// ─── Capacity Progress Bar ────────────────────────────────────────────────────

function capacityBar(int $registered, int $capacity): string {
    $pct = $capacity > 0 ? min(100, round(($registered / $capacity) * 100)) : 0;
    $color = $pct < 50 ? 'success' : ($pct < 80 ? 'warning' : 'danger');
    return sprintf(
        '<div class="capacity-bar">
            <div class="d-flex justify-content-between small mb-1">
                <span>%d / %d seats</span><span>%d%%</span>
            </div>
            <div class="progress" style="height:6px">
                <div class="progress-bar bg-%s" style="width:%d%%"></div>
            </div>
        </div>',
        $registered, $capacity, $pct, $color, $pct
    );
}
