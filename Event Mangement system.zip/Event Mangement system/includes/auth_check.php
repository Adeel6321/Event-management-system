<?php
/**
 * EMS — Authentication & Role Guard Middleware
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/functions.php';

/**
 * Require user to be logged in; redirect to login otherwise.
 */
function requireLogin(string $redirect = '/auth/login.php'): void {
    if (!isLoggedIn()) {
        $_SESSION['intended'] = $_SERVER['REQUEST_URI'] ?? '';
        setFlash('warning', 'Please log in to continue.');
        redirect(SITE_URL . $redirect);
    }
}

/**
 * Require user to have admin role.
 */
function requireAdmin(): void {
    requireLogin();
    if (!isAdmin()) {
        setFlash('danger', 'Access denied. Admin privileges required.');
        redirect(SITE_URL . '/index.php');
    }
}

/**
 * Require admin or organizer role.
 */
function requireOrganizer(): void {
    requireLogin();
    if (!isOrganizer()) {
        setFlash('danger', 'Access denied. Organizer privileges required.');
        redirect(SITE_URL . '/index.php');
    }
}

/**
 * Redirect logged-in users away from guest-only pages (login, register).
 */
function redirectIfLoggedIn(string $to = '/index.php'): void {
    if (isLoggedIn()) {
        redirect(SITE_URL . $to);
    }
}

/**
 * Enforce HTTPS in production (optional — uncomment when using SSL).
 */
// function requireHttps(): void {
//     if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
//         redirect('https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
//     }
// }
