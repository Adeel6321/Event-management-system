<?php
/**
 * EMS — Global Header / Navigation
 * Variables expected:
 *   $pageTitle   (string) — page title
 *   $activePage  (string) — active nav link key
 *   $extraHead   (string) — additional <head> content
 */
if (!isset($pageTitle))  $pageTitle  = 'EMS — Event Management System';
if (!isset($activePage)) $activePage = '';
if (!isset($extraHead))  $extraHead  = '';

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/includes/functions.php';

$sessionUser = currentUser();
$user = null;
if ($sessionUser && isset($pdo)) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$sessionUser['id']]);
    $user = $stmt->fetch();
}
$unread = ($user && isset($pdo)) ? getUnreadCount($pdo, $user['id']) : 0;

// Fetch latest 5 notifications for dropdown
$notifications = [];
if ($user && $pdo) {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY sent_at DESC LIMIT 5");
    $stmt->execute([$user['id']]);
    $notifications = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Event Management System — IUB, Department of Information Technology. Discover, book and manage events online.">
  <meta name="author" content="Muhammad Adeel Jameel">
  <meta name="theme-color" content="#7c3aed">

  <title><?= e($pageTitle) ?> | EMS — IUB</title>

  <!-- Favicon -->
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎫</text></svg>">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

  <!-- EMS Custom CSS -->
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">

  <?= $extraHead ?>
  
  <!-- Theme Init Script -->
  <script>
    const savedTheme = localStorage.getItem('ems-theme');
    if (savedTheme) { document.documentElement.setAttribute('data-theme', savedTheme); }
  </script>
</head>
<body>

<!-- Animated Background -->
<div class="bg-mesh" aria-hidden="true"></div>

<!-- ─── NAVBAR ─────────────────────────────────────────────────────── -->
<nav class="ems-navbar" role="navigation" aria-label="Main navigation">
  <div class="container-fluid d-flex align-items-center gap-3">

    <!-- Brand -->
    <a href="<?= SITE_URL ?>/index.php" class="navbar-brand-ems me-auto me-lg-4" aria-label="EMS Home">
      <div class="brand-icon" aria-hidden="true">🎫</div>
      <span class="brand-text d-none d-sm-block">EMS<span>·IUB</span></span>
    </a>

    <!-- Desktop Nav Links -->
    <div class="d-none d-lg-flex align-items-center gap-1">
      <a href="<?= SITE_URL ?>/index.php"
         class="nav-link-ems <?= $activePage === 'home' ? 'active' : '' ?>">
        <i class="bi bi-house-door me-1"></i>Home
      </a>
      <a href="<?= SITE_URL ?>/events/index.php"
         class="nav-link-ems <?= $activePage === 'events' ? 'active' : '' ?>">
        <i class="bi bi-calendar-event me-1"></i>Events
      </a>
      <a href="<?= SITE_URL ?>/venues/index.php"
         class="nav-link-ems <?= $activePage === 'venues' ? 'active' : '' ?>">
        <i class="bi bi-geo-alt me-1"></i>Venues
      </a>
      <?php if (isOrganizer()): ?>
      <a href="<?= SITE_URL ?>/events/create.php"
         class="nav-link-ems <?= $activePage === 'create_event' ? 'active' : '' ?>">
        <i class="bi bi-plus-circle me-1"></i>Create Event
      </a>
      <?php endif; ?>
      <?php if (isAdmin()): ?>
      <a href="<?= SITE_URL ?>/admin/dashboard.php"
         class="nav-link-ems <?= $activePage === 'admin' ? 'active' : '' ?>">
        <i class="bi bi-speedometer2 me-1"></i>Dashboard
      </a>
      <?php endif; ?>
    </div>

    <!-- Right Side -->
    <div class="d-flex align-items-center gap-2 ms-auto">

      <!-- Theme Switcher Dropdown -->
      <div class="dropdown">
        <div class="notif-bell dropdown-toggle" id="themeMenu" data-bs-toggle="dropdown" aria-expanded="false" role="button" title="Color Theme">
          <i class="bi bi-palette"></i>
        </div>
        <div class="dropdown-menu-ems dropdown-menu dropdown-menu-end p-3" aria-labelledby="themeMenu" style="min-width:180px;z-index:9999;">
          <div style="font-weight:700;font-size:.9rem;margin-bottom:10px">Color Theme</div>
          <div class="d-flex gap-2 flex-wrap">
            <span class="theme-swatch theme-default" onclick="setTheme('default')" title="Purple (Default)"></span>
            <span class="theme-swatch theme-blue" onclick="setTheme('blue')" title="Blue"></span>
            <span class="theme-swatch theme-green" onclick="setTheme('green')" title="Green"></span>
            <span class="theme-swatch theme-pink" onclick="setTheme('pink')" title="Pink"></span>
            <span class="theme-swatch theme-cyan" onclick="setTheme('cyan')" title="Cyan"></span>
          </div>
        </div>
      </div>

      <?php if ($user): ?>
        <!-- Notification Bell -->
        <div class="position-relative" id="notifBell" role="button" aria-label="Notifications" tabindex="0">
          <div class="notif-bell">
            <i class="bi bi-bell"></i>
            <?php if ($unread > 0): ?>
              <div class="notif-badge" id="notifBadge"><?= $unread > 9 ? '9+' : $unread ?></div>
            <?php endif; ?>
          </div>
          <!-- Notification Dropdown -->
          <div id="notifDropdown"
               class="position-absolute end-0 mt-2 glass-strong"
               style="width:340px;display:none;border-radius:var(--r-lg);box-shadow:var(--shadow-purple);z-index:999;"
               onclick="event.stopPropagation()">
            <div class="d-flex align-items-center justify-content-between p-3 border-bottom border-glass">
              <span style="font-weight:700;font-size:.95rem">Notifications</span>
              <?php if ($unread > 0): ?>
                <span class="badge badge-purple"><?= $unread ?> new</span>
              <?php endif; ?>
            </div>
            <?php if (empty($notifications)): ?>
              <div class="p-4 text-center" style="color:var(--text-muted)">
                <i class="bi bi-bell-slash d-block mb-2" style="font-size:1.5rem"></i>
                No notifications yet
              </div>
            <?php else: ?>
              <?php foreach ($notifications as $notif): ?>
                <div class="notif-item <?= $notif['status'] === 'unread' ? 'unread' : '' ?>">
                  <div class="notif-icon-wrap" style="background:rgba(124,58,237,.1);color:var(--purple-light)">
                    <i class="bi <?= notifIcon($notif['type']) ?>"></i>
                  </div>
                  <div>
                    <div class="notif-title"><?= e($notif['title']) ?></div>
                    <div class="notif-msg"><?= e(mb_substr($notif['message'], 0, 70)) ?>...</div>
                    <div class="notif-time"><i class="bi bi-clock me-1"></i><?= timeAgo($notif['sent_at']) ?></div>
                  </div>
                </div>
              <?php endforeach; ?>
              <div class="p-2 text-center">
                <a href="<?= SITE_URL ?>/notifications/index.php" class="btn-ems btn-ghost-ems btn-sm-ems" style="font-size:.8rem">
                  View all notifications
                </a>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- User Avatar Dropdown -->
        <div class="dropdown">
          <div class="avatar-btn dropdown-toggle" id="userMenu" data-bs-toggle="dropdown" aria-expanded="false" role="button">
            <?php if(!empty($user['profile_image'])): ?>
              <div class="avatar-circle" style="background-image:url('<?= SITE_URL ?>/assets/uploads/<?= e($user['profile_image']) ?>');background-size:cover;background-position:center;"></div>
            <?php else: ?>
              <div class="avatar-circle"><?= strtoupper(substr($user['name'], 0, 1)) ?></div>
            <?php endif; ?>
            <span class="d-none d-sm-block" style="font-size:.88rem;font-weight:600">
              <?= e(explode(' ', $user['name'])[0]) ?>
            </span>
          </div>
          <ul class="dropdown-menu-ems dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
            <li class="px-3 py-2" style="border-bottom:1px solid var(--border-glass)">
              <div style="font-weight:700;font-size:.9rem"><?= e($user['name']) ?></div>
              <div style="font-size:.78rem;color:var(--text-muted)"><?= e($user['email']) ?></div>
              <span class="badge badge-purple mt-1"><?= ucfirst($user['role']) ?></span>
            </li>
            <li>
              <a href="<?= SITE_URL ?>/profile/edit.php" class="dropdown-item-ems">
                <i class="bi bi-person-circle"></i> My Profile
              </a>
            </li>
            <li>
              <a href="<?= SITE_URL ?>/bookings/my_bookings.php" class="dropdown-item-ems">
                <i class="bi bi-ticket-perforated"></i> My Bookings
              </a>
            </li>
            <li>
              <a href="<?= SITE_URL ?>/notifications/index.php" class="dropdown-item-ems">
                <i class="bi bi-bell"></i> Notifications
                <?php if ($unread > 0): ?>
                  <span class="badge badge-purple ms-auto"><?= $unread ?></span>
                <?php endif; ?>
              </a>
            </li>
            <?php if (isAdmin()): ?>
            <li><hr class="dropdown-divider-ems dropdown-divider"></li>
            <li>
              <a href="<?= SITE_URL ?>/admin/dashboard.php" class="dropdown-item-ems">
                <i class="bi bi-speedometer2"></i> Admin Dashboard
              </a>
            </li>
            <?php endif; ?>
            <li><hr class="dropdown-divider-ems dropdown-divider"></li>
            <li>
              <a href="<?= SITE_URL ?>/auth/logout.php" class="dropdown-item-ems danger"
                 data-confirm="Are you sure you want to log out?">
                <i class="bi bi-box-arrow-right"></i> Logout
              </a>
            </li>
          </ul>
        </div>

      <?php else: ?>
        <!-- Guest Buttons -->
        <a href="<?= SITE_URL ?>/auth/login.php" class="btn-ems btn-ghost-ems btn-sm-ems d-none d-sm-flex">
          <i class="bi bi-box-arrow-in-right"></i> Login
        </a>
        <a href="<?= SITE_URL ?>/auth/register.php" class="btn-ems btn-primary-ems btn-sm-ems">
          <i class="bi bi-person-plus"></i>
          <span class="d-none d-sm-inline">Register</span>
        </a>
      <?php endif; ?>

      <!-- Mobile Nav Toggle -->
      <button class="btn-ems btn-ghost-ems btn-sm-ems d-lg-none" id="mobileNavToggle"
              data-bs-toggle="collapse" data-bs-target="#mobileNav"
              aria-controls="mobileNav" aria-expanded="false" aria-label="Toggle navigation">
        <i class="bi bi-list" style="font-size:1.2rem"></i>
      </button>
    </div>
  </div>
</nav>

<!-- Mobile Nav -->
<div class="collapse" id="mobileNav">
  <div class="glass-strong" style="border-radius:0;border-top:none;padding:1rem">
    <div class="d-flex flex-column gap-1">
      <a href="<?= SITE_URL ?>/index.php" class="nav-link-ems <?= $activePage === 'home' ? 'active' : '' ?>">
        <i class="bi bi-house-door me-2"></i>Home
      </a>
      <a href="<?= SITE_URL ?>/events/index.php" class="nav-link-ems <?= $activePage === 'events' ? 'active' : '' ?>">
        <i class="bi bi-calendar-event me-2"></i>Events
      </a>
      <a href="<?= SITE_URL ?>/venues/index.php" class="nav-link-ems <?= $activePage === 'venues' ? 'active' : '' ?>">
        <i class="bi bi-geo-alt me-2"></i>Venues
      </a>
      <?php if ($user): ?>
      <a href="<?= SITE_URL ?>/bookings/my_bookings.php" class="nav-link-ems">
        <i class="bi bi-ticket-perforated me-2"></i>My Bookings
      </a>
      <?php if (isOrganizer()): ?>
      <a href="<?= SITE_URL ?>/events/create.php" class="nav-link-ems">
        <i class="bi bi-plus-circle me-2"></i>Create Event
      </a>
      <?php endif; ?>
      <?php if (isAdmin()): ?>
      <a href="<?= SITE_URL ?>/admin/dashboard.php" class="nav-link-ems">
        <i class="bi bi-speedometer2 me-2"></i>Dashboard
      </a>
      <?php endif; ?>
      <a href="<?= SITE_URL ?>/auth/logout.php" class="nav-link-ems" style="color:var(--red)!important">
        <i class="bi bi-box-arrow-right me-2"></i>Logout
      </a>
      <?php else: ?>
      <a href="<?= SITE_URL ?>/auth/login.php" class="nav-link-ems">
        <i class="bi bi-box-arrow-in-right me-2"></i>Login
      </a>
      <a href="<?= SITE_URL ?>/auth/register.php" class="nav-link-ems">
        <i class="bi bi-person-plus me-2"></i>Register
      </a>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Flash Message (global) -->
<div class="container mt-3" id="flashContainer">
  <?= renderFlash() ?>
</div>

<!-- Page content starts here -->
<?php

// Helper for notification icon in header
function notifIcon(string $type): string {
    return match($type) {
        'booking'      => 'bi-ticket-perforated-fill',
        'cancellation' => 'bi-x-circle-fill',
        'reminder'     => 'bi-alarm-fill',
        'update'       => 'bi-arrow-repeat',
        default        => 'bi-bell-fill',
    };
}
?>
