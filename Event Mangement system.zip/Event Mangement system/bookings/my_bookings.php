<?php
/**
 * EMS — User Bookings List
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireLogin();

$pageTitle  = 'My Bookings';
$activePage = 'bookings';

// Fetch user's bookings
$stmt = $pdo->prepare("
    SELECT b.*, e.title, e.date, e.time, e.category, e.status AS event_status, 
           v.name AS venue_name
    FROM bookings b
    JOIN events e ON b.event_id = e.id
    LEFT JOIN venues v ON e.venue_id = v.id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$bookings = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
  <div class="d-flex align-items-center justify-content-between mb-4 scroll-animate">
    <h1 class="page-title mb-0">My Bookings</h1>
    <a href="<?= SITE_URL ?>/events/index.php" class="btn-ems btn-outline-ems btn-sm-ems">
      <i class="bi bi-calendar-event me-1"></i> Browse Events
    </a>
  </div>

  <?php if (empty($bookings)): ?>
    <div class="empty-state scroll-animate card-ems p-5">
      <i class="bi bi-ticket-perforated"></i>
      <h4>No bookings yet</h4>
      <p>You haven't booked any events. Explore our upcoming events to get started.</p>
      <a href="<?= SITE_URL ?>/events/index.php" class="btn-ems btn-primary-ems mt-3">Explore Events</a>
    </div>
  <?php else: ?>
    <div class="row g-4">
      <?php foreach ($bookings as $b): ?>
      <div class="col-lg-6 scroll-animate">
        <div class="booking-card position-relative overflow-hidden">
          
          <!-- Category Accent Line -->
          <div style="position:absolute;top:0;left:0;bottom:0;width:4px;background:<?= categoryColor($b['category']) ?>"></div>
          
          <div class="d-flex justify-content-between align-items-start mb-3 ms-2">
            <div>
              <div style="font-size:.75rem;color:var(--text-muted);margin-bottom:4px">
                Ref: <span class="text-primary fw-bold"><?= $b['booking_reference'] ?></span>
                &bull; Booked <?= timeAgo($b['created_at']) ?>
              </div>
              <h4 class="mb-1">
                <a href="<?= SITE_URL ?>/events/detail.php?id=<?= $b['event_id'] ?>" style="color:var(--text-primary)"><?= e($b['title']) ?></a>
              </h4>
            </div>
            <?= statusBadge($b['status']) ?>
          </div>

          <div class="bg-input rounded-ems p-3 mb-3 ms-2" style="background:rgba(255,255,255,.02);border:1px solid var(--border-glass)">
            <div class="row g-2">
              <div class="col-6">
                <div class="text-muted" style="font-size:.75rem">Date & Time</div>
                <div style="font-size:.85rem"><i class="bi bi-calendar3 text-purple me-1"></i> <?= formatDate($b['date']) ?><br><?= formatTime($b['time']) ?></div>
              </div>
              <div class="col-6">
                <div class="text-muted" style="font-size:.75rem">Venue</div>
                <div style="font-size:.85rem"><i class="bi bi-geo-alt text-purple me-1"></i> <?= e($b['venue_name'] ?: 'TBA') ?></div>
              </div>
              <div class="col-6 mt-3">
                <div class="text-muted" style="font-size:.75rem">Tickets</div>
                <div style="font-size:.85rem"><i class="bi bi-ticket-detailed text-purple me-1"></i> <?= $b['quantity'] ?> Seat(s)</div>
              </div>
              <div class="col-6 mt-3">
                <div class="text-muted" style="font-size:.75rem">Total Price</div>
                <div style="font-size:.85rem;font-weight:600" class="text-gold">
                  <?= $b['total_price'] > 0 ? 'PKR ' . number_format($b['total_price']) : 'Free' ?>
                </div>
              </div>
            </div>
          </div>

          <div class="d-flex gap-2 ms-2">
            <a href="<?= SITE_URL ?>/events/detail.php?id=<?= $b['event_id'] ?>" class="btn-ems btn-ghost-ems btn-sm-ems flex-grow-1 justify-content-center">
              Event Details
            </a>
            <?php if ($b['status'] === 'confirmed' && $b['event_status'] !== 'completed' && strtotime($b['date']) > time()): ?>
              <form action="cancel.php" method="POST" class="flex-grow-1 d-flex">
                <?= csrfField() ?>
                <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                <button type="submit" class="btn-ems btn-outline-ems btn-sm-ems w-100 justify-content-center text-danger border-danger" data-confirm="Are you sure you want to cancel this booking? This action cannot be undone.">
                  Cancel Booking
                </button>
              </form>
            <?php endif; ?>
          </div>
          
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
