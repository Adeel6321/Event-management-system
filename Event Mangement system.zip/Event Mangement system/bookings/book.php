<?php
/**
 * EMS — Book Event Slot
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/mailer.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireLogin('/auth/login.php');

$eventId = (int)($_GET['event_id'] ?? 0);
if (!$eventId) redirect(SITE_URL . '/events/index.php');

$stmt = $pdo->prepare("
    SELECT e.*, v.name AS venue_name, v.city
    FROM events e
    LEFT JOIN venues v ON e.venue_id = v.id
    WHERE e.id = ? AND e.status = 'published'
");
$stmt->execute([$eventId]);
$event = $stmt->fetch();

if (!$event) {
    setFlash('danger', 'Event not found or unavailable.');
    redirect(SITE_URL . '/events/index.php');
}

$seatsLeft = $event['capacity'] - $event['registered'];
$isPast    = strtotime($event['date'] . ' ' . $event['time']) < time();

if ($isPast || $seatsLeft <= 0) {
    setFlash('warning', 'Sorry, booking is closed for this event.');
    redirect(SITE_URL . '/events/detail.php?id=' . $eventId);
}

// Check double booking
$stmt = $pdo->prepare("SELECT id FROM bookings WHERE user_id = ? AND event_id = ? AND status != 'cancelled'");
$stmt->execute([$_SESSION['user_id'], $eventId]);
if ($stmt->fetch()) {
    setFlash('info', 'You have already booked a seat for this event.');
    redirect(SITE_URL . '/bookings/my_bookings.php');
}

$pageTitle = 'Book Event — ' . $event['title'];
$errors    = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please try again.';
    } else {
        $qty   = (int)($_POST['quantity'] ?? 1);
        $notes = $_POST['notes'] ?? '';

        if ($qty < 1 || $qty > 5) {
            $errors[] = 'You can book between 1 and 5 tickets.';
        } elseif ($qty > $seatsLeft) {
            $errors[] = "Only {$seatsLeft} seats available.";
        } else {
            $totalPrice = $event['type'] === 'free' ? 0 : ($event['ticket_price'] * $qty);
            $ref        = generateBookingRef();

            try {
                $pdo->beginTransaction();

                // Double check capacity (row locking / basic check)
                $stmt = $pdo->prepare("SELECT capacity, registered FROM events WHERE id = ? FOR UPDATE");
                $stmt->execute([$eventId]);
                $freshEvent = $stmt->fetch();
                $freshSeats = $freshEvent['capacity'] - $freshEvent['registered'];

                if ($qty > $freshSeats) {
                    throw new Exception("Only {$freshSeats} seats left. Please refresh and try again.");
                }

                // Insert booking
                $stmt = $pdo->prepare('INSERT INTO bookings (user_id, event_id, quantity, total_price, status, booking_reference, notes) VALUES (?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$_SESSION['user_id'], $eventId, $qty, $totalPrice, 'confirmed', $ref, $notes]);
                $bookingId = $pdo->lastInsertId();

                // Update event registered count
                $stmt = $pdo->prepare('UPDATE events SET registered = registered + ? WHERE id = ?');
                $stmt->execute([$qty, $eventId]);

                $pdo->commit();

                // Notifications
                $bookingDetails = ['quantity' => $qty, 'total_price' => $totalPrice, 'booking_reference' => $ref];
                createNotification($pdo, $_SESSION['user_id'], 'Booking Confirmed!', "Your booking for {$event['title']} (Ref: {$ref}) is confirmed.", 'booking', "/bookings/my_bookings.php");
                
                // Send email
                $user = currentUser();
                sendBookingConfirmationEmail($user['email'], $user['name'], $bookingDetails, $event);

                setFlash('success', 'Booking successful! Reference: ' . $ref);
                redirect(SITE_URL . '/bookings/my_bookings.php');

            } catch (Exception $e) {
                $pdo->rollBack();
                $errors[] = $e->getMessage();
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-8 scroll-animate">

      <div class="mb-4">
        <a href="<?= SITE_URL ?>/events/detail.php?id=<?= $eventId ?>" class="text-secondary" style="text-decoration:none">
          <i class="bi bi-arrow-left"></i> Back to Event
        </a>
      </div>

      <div class="card-ems p-0 overflow-hidden mb-4 border-purple">
        <div class="bg-mesh" style="opacity:0.5;z-index:0"></div>
        <div class="position-relative p-4 p-md-5" style="z-index:1;background:rgba(15,23,42,0.7)">
          <div class="d-flex align-items-center gap-3 mb-3">
            <div class="stat-icon purple" style="width:48px;height:48px;font-size:1.2rem">
              <i class="bi bi-ticket-perforated-fill"></i>
            </div>
            <div>
              <h2 class="mb-0" style="font-size:1.5rem">Book Tickets</h2>
              <div class="text-purple"><?= e($event['title']) ?></div>
            </div>
          </div>
          <div class="d-flex flex-wrap gap-4 text-secondary mt-4" style="font-size:.9rem">
            <div><i class="bi bi-calendar3 me-1"></i> <?= formatDate($event['date']) ?> at <?= formatTime($event['time']) ?></div>
            <div><i class="bi bi-geo-alt me-1"></i> <?= e($event['venue_name']) ?></div>
          </div>
        </div>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert-custom alert-danger mb-4">
          <ul class="mb-0 ps-3">
            <?php foreach ($errors as $e) echo "<li>" . e($e) . "</li>"; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="">
        <?= csrfField() ?>
        
        <div class="card-ems p-4 mb-4">
          <h5 class="mb-3">Select Quantity</h5>
          
          <div class="d-flex justify-content-between align-items-center p-3 rounded-ems mb-3" style="background:var(--bg-input);border:1px solid var(--border-glass)">
            <div>
              <div class="fw-bold text-primary">General Admission</div>
              <div class="text-secondary" style="font-size:.85rem" id="pricePerTicket" data-price="<?= $event['ticket_price'] ?>">
                <?= $event['type'] === 'free' ? 'Free' : 'PKR ' . number_format($event['ticket_price']) ?>
              </div>
            </div>
            <div class="d-flex align-items-center gap-2">
              <button type="button" class="btn-ems btn-ghost-ems px-2 py-1" id="qtyMinus" style="min-width:32px">-</button>
              <input type="number" name="quantity" id="qtyInput" value="1" min="1" max="<?= min(5, $seatsLeft) ?>" 
                     class="form-control-ems text-center" style="width:60px;padding:.3rem" readonly>
              <button type="button" class="btn-ems btn-ghost-ems px-2 py-1" id="qtyPlus" style="min-width:32px">+</button>
            </div>
          </div>
          
          <div class="text-muted" style="font-size:.8rem">
            <i class="bi bi-info-circle me-1"></i> Max 5 tickets per user. Only <?= $seatsLeft ?> seats left.
          </div>
        </div>

        <div class="card-ems p-4 mb-4">
          <h5 class="mb-3">Additional Information</h5>
          <div class="form-group-ems mb-0">
            <label class="form-label-ems">Special Requests / Notes (Optional)</label>
            <textarea name="notes" class="form-control-ems" rows="2" placeholder="Dietary requirements, accessibility needs, etc."></textarea>
          </div>
        </div>

        <div class="card-ems p-4 mb-4" style="background:rgba(124,58,237,.05);border-color:var(--purple-light)">
          <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Total Due</h5>
            <div class="fs-3 fw-bold text-gradient" id="totalPrice">
              <?= $event['type'] === 'free' ? 'Free' : 'PKR ' . number_format($event['ticket_price']) ?>
            </div>
          </div>
        </div>

        <button type="submit" class="btn-ems btn-primary-ems w-100 justify-content-center btn-lg-ems">
          Confirm Booking <i class="bi bi-check-circle-fill ms-1"></i>
        </button>

      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
