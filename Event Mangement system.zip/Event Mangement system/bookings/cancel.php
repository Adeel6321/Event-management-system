<?php
/**
 * EMS — Cancel Booking Action
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/mailer.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    setFlash('danger', 'Invalid request.');
    redirect(SITE_URL . '/bookings/my_bookings.php');
}

$bookingId = (int)($_POST['booking_id'] ?? 0);

try {
    $pdo->beginTransaction();

    // Fetch booking details ensuring it belongs to the user
    $stmt = $pdo->prepare("
        SELECT b.*, e.title, e.date 
        FROM bookings b
        JOIN events e ON b.event_id = e.id
        WHERE b.id = ? AND b.user_id = ? AND b.status = 'confirmed'
        FOR UPDATE
    ");
    $stmt->execute([$bookingId, $_SESSION['user_id']]);
    $booking = $stmt->fetch();

    if (!$booking) {
        throw new Exception("Booking not found or already cancelled.");
    }

    // Check if event is in the past
    if (strtotime($booking['date']) < time()) {
        throw new Exception("Cannot cancel bookings for past events.");
    }

    // Update booking status
    $stmt = $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?");
    $stmt->execute([$bookingId]);

    // Restore event capacity
    $stmt = $pdo->prepare("UPDATE events SET registered = registered - ? WHERE id = ?");
    $stmt->execute([$booking['quantity'], $booking['event_id']]);

    $pdo->commit();

    // Notify user
    createNotification($pdo, $_SESSION['user_id'], 'Booking Cancelled', "Your booking for {$booking['title']} has been cancelled.", 'cancellation', '');
    
    // Send Email
    $user = currentUser();
    sendCancellationEmail($user['email'], $user['name'], $booking);

    setFlash('success', 'Booking cancelled successfully.');

} catch (Exception $e) {
    $pdo->rollBack();
    setFlash('danger', $e->getMessage());
}

redirect(SITE_URL . '/bookings/my_bookings.php');
